@extends('admin/layout')

@section('content')
<script src="/dash/js/dtables.js?v={{time()}}" type="text/javascript"></script>
<div class="kt-subheader kt-grid__item" id="kt_subheader">
    <div class="kt-subheader__main">
        <h3 class="kt-subheader__title">Выплаты</h3>
    </div>
</div>

<div class="kt-content kt-grid__item kt-grid__item--fluid" id="kt_content">
    <div class="kt-portlet kt-portlet--mobile">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon2-information"></i>
                </span>
                <h3 class="kt-portlet__head-title">
                    Активные выплаты
                </h3>
            </div>
        </div>
        <div class="kt-portlet__body">

            <!--begin: Datatable -->
            <table class="table table-striped- table-bordered table-hover table-checkable" id="dtable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Пользователь</th>
                        <th>Сумма</th>
                        <td>Кошелек</td>
                        <td>Система</td>
                        <th>Действие</th>
                    </tr>
                </thead>
                <tbody>
                @foreach(\App\Withdraw::query()->where('status', 0)->get() as $withdraw)
                    @if (\App\User::query()->find($withdraw->user_id))
                        @php
                            $username = \App\User::query()->find($withdraw->user_id)->username;
                        @endphp
                        <tr>
                            <td>{{ $withdraw->id }}</td>
                            <td><a href="/admin/users/edit/{{$withdraw->user_id}}">{{ $username }}</a></td>
                            <td>{{ $withdraw->sum }}р. ({{ $withdraw->sumWithCom }}р.)</td>
                            <td>{{ $withdraw->wallet }}</td>
                            <td>{{ \App\Http\Controllers\WithdrawController::SYSTEMS[$withdraw->system] }}</td>
                                @if ($withdraw->status === 0)
                            <td>
                            <a href="{{ route('admin.withdraws.save', ['id' => $withdraw->id, 'status' => 3]) }}" class="btn btn-sm btn-success btn-sm btn-icon btn-icon-md" title="Выплатить"><i class="la la-check"></i></a>
                            <a href="javascript://" onclick="declineWithdraw('{{$withdraw->id}}', '{{$username}}', '{{$withdraw->wallet}}', '{{$withdraw->sum}}')" class="btn btn-sm btn-danger btn-sm btn-icon btn-icon-md" title="Удалить"><i class="la la-trash"></i></a>
                            </td>
                            @endif
                        </tr>
                    @endif
                @endforeach
                </tbody>
            </table>

            <!--end: Datatable -->
        </div>
    </div>
    <div class="kt-portlet kt-portlet--mobile">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon2-checkmark"></i>
                </span>
                <h3 class="kt-portlet__head-title">
                    Обработанные запросы
                </h3>
            </div>
        </div>
        <div class="kt-portlet__body">

            <!--begin: Datatable -->
            <table class="table table-striped- table-bordered table-hover table-checkable" id="dtable2">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Пользователь</th>
                        <th>Сумма</th>
                        <td>Кошелек</td>
                        <td>Система</td>
                    </tr>
                </thead>
                <tbody>
                @foreach(\App\Withdraw::query()->where('status', 1)->get() as $withdraw)
                    @if (\App\User::query()->find($withdraw->user_id))
                        <tr>
                            <td>{{ $withdraw->id }}</td>
                            <td><a href="/admin/users/edit/{{$withdraw->user_id}}">{{ \App\User::query()->find($withdraw->user_id)->username }}</a></td>
                            <td>{{ $withdraw->sum }}</td>
                            <td>{{ $withdraw->wallet }}</td>
                            <td>{{ \App\Http\Controllers\WithdrawController::SYSTEMS[$withdraw->system] }}</td>
                        </tr>
                    @endif
                @endforeach
                </tbody>
            </table>

            <!--end: Datatable -->
        </div>
    </div>
    <div class="kt-portlet kt-portlet--mobile">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon2-close-cross"></i>
                </span>
                <h3 class="kt-portlet__head-title">
                    Отклоненные запросы
                </h3>
            </div>
        </div>
        <div class="kt-portlet__body">

            <!--begin: Datatable -->
            <table class="table table-striped- table-bordered table-hover table-checkable" id="dtable3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Пользователь</th>
                        <th>Сумма</th>
                        <td>Кошелек</td>
                        <td>Система</td>
                    </tr>
                </thead>
                <tbody>
                @foreach(\App\Withdraw::query()->where('status', 2)->get() as $withdraw)
                    @if (\App\User::query()->find($withdraw->user_id))
                        <tr>
                            <td>{{ $withdraw->id }}</td>
                            <td><a href="/admin/users/edit/{{$withdraw->user_id}}">{{ \App\User::query()->find($withdraw->user_id)->username }}</a></td>
                            <td>{{ $withdraw->sum }}</td>
                            <td>{{ $withdraw->wallet }}</td>
                            <td>{{ \App\Http\Controllers\WithdrawController::SYSTEMS[$withdraw->system] }}</td>
                        </tr>
                    @endif
                @endforeach
                </tbody>
            </table>

            <!--end: Datatable -->
        </div>
    </div>
</div>
<div class="modal fade" id="declineWithdrawModal" tabindex="-1" role="dialog" aria-labelledby="newLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Отмена выплаты</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <form class="kt-form-new" action="#" id="save">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="name">Логин:</label>
                        <input type="text" class="form-control" placeholder="" id="decline_login" disabled readonly />
                    </div>
                    <div class="form-group">
                        <label for="name">Кошелек:</label>
                        <input type="text" class="form-control" placeholder="" id="decline_wallet" disabled readonly />
                    </div>
                    <div class="form-group">
                        <label for="name">Сумма:</label>
                        <input type="text" class="form-control" placeholder="" id="decline_amount" disabled readonly />
                    </div>
                    <div class="form-group">
                        <label for="decline_reason">Причина отмены:</label>
                        <textarea type="text" class="form-control" id="decline_reason"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
                    <button type="submit" class="btn btn-primary declineButton" onclick="saveDeclineReason()">Отменить выплату</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
var showId = 0;
const declineWithdraw = (id, login, wallet, amount) => {
    showId = id;
    $('#declineWithdrawModal').modal('show');
    $('#decline_login').val(login)
    $('#decline_wallet').val(wallet)
    $('#decline_amount').val(amount)
}
const saveDeclineReason = () => {
    var reason = $('#decline_reason').val();
    $('.declineButton').attr('disabled', true)
    $.post('/admin/withdraws/decline', {
        id: showId,
        status: 2,
        reason: reason
    })
    .then(response => {
        const data = response;

        //$('.declineButton').attr('disabled', false);
        $('#dtable').init()
        if(data.error) {
            $.notify({
                type: 'error',
                message: data.error
            });
        }

        $.notify({
            type: 'success',
            message: "Выплата отменена"
        });
        showId = 0;
        $('#decline_reason').val('');
        //$('#declineWithdrawModal').modal('hide');
        setTimeout(() => {
            location.reload(true);
        }, 1500)
    })
}
</script>
<style>
    input.form-control:disabled {
        background: #f7f7f7!important
    }
</style>
@endsection
