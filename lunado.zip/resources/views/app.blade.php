<!-- GP_E4cb5ST9kUWy2jEhpnXSXZaELNXCVQps; -->
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <link rel="shortcut icon" type="image/x-icon" href="favicon.png">
        <title>{{ $settings->title }}</title>
        <meta name="description" content="{{ $settings->description }}">
        <meta name="keywords" content="{{ $settings->keywords }}">
        <meta name="xmpay" content="955c309aa70943c6e815c9f671111d959034dadc19b9952500b94409325c6cc8">
        <link href="{{ asset('assets/css/main.css') }}?v={{ $settings->file_version }}" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@400&display=swap" rel="stylesheet">
        <style>
            *:not(.fas, .fa, .fad, .fa-solid) {
                font-family: 'Rubik', sans-serif!important;
            }
        </style>
    <body>
        <noscript>You need to enable JavaScript to run this app.</noscript>
        <div id="root"></div>
        <div class="errors" style="display: none">{{ session('error') }}</div>
    </body>
    <script src="https://kit.fontawesome.com/218a2a412a.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
    <script src="{{ mix('js/app.js') }}?v={{ $settings->file_version }}"></script>
    @php
        if(isset($_GET['invite'])) {
            session_start();
            $_SESSION['ref'] = $_GET['invite'];
        }
    @endphp
    <style>
        .typed-cursor {
            display: none!important
        }

        .vm--modal {
            border-radius: 6px!important;
        }
    </style>
</html>
