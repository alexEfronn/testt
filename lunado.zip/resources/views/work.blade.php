<html lang="ru">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, , maximum-scale=1, shrink-to-fit=no">
    </head>
    <style>
        .text-center {
            text-align: center
        }
    </style>
    <body class="text-center">
        На сайте ведутся технические работы.
    </body>
</html>