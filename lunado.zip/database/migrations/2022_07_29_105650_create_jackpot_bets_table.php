<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateJackpotBetsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jackpot_bets', function (Blueprint $table) {
            $table->id();
            $table->string('game_id');
            $table->string('user_id');
            $table->float('amount');
            $table->string('ticket_from');
            $table->string('ticket_to');
            $table->string('chance');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jackpot_bets');
    }
};
