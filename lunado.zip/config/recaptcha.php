<?php

return [
    'secret' => env('RECAPTCHA_SECRET_KEY')
];
