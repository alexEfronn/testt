<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JackpotBets extends Model
{
    protected $fillable = [
        'game_id',
        'user_id',
        'amount',
        'ticket_from',
        'ticket_to',
        'chance'
    ];
}
