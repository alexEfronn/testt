<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $fillable = [
        'title',
        'description',
        'keywords',
        'kassa_id',
        'kassa_secret1',
        'kassa_secret2',
        'kassa_key',
        'wallet_id',
        'wallet_secret',
        'wallet_desc',
        'xmpay_id',
        'xmpay_public',
        'xmpay_secret',
        'min_payment_sum',
        'min_bonus_sum',
        'min_withdraw_sum',
        'withdraw_request_limit',
        'bot_timer',
        'min_dep_withdraw',
        'vk_url',
        'vk_id',
        'vk_token',
        'ref_perc',
        'ref_price',
        'file_version',
        'connect_bonus',
        'antiminus',
        'recapctha_site',
        'recapctha_secret',
        'vk_support_url',
        'tg_channel',
        'tg_bot'
    ];
}
