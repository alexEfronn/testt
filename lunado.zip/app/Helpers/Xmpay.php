<?php

namespace App\Helpers;

class XMpay 
{
    const MERCHANT_ID = 0;
    const PUBLIC_KEY = '';
    const SECRET_KEY = '';

    public function createOrder(float $amount, string $label, ?string $system): array 
    {
        $data = [
            'merchant_id' => static::MERCHANT_ID,
            'public_key' => static::PUBLIC_KEY,
            'amount' => $amount,
            'label' => $label
        ];

        if($system) {
            $data['system'] = $system;
        }

        $ch = curl_init('https://xmpay.one/api/createOrder');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);
        return $data;
    }

    public function createWithdraw(float $amount, string $wallet, string $system): array
    {
        $data = [
            'merchant_id' => static::MERCHANT_ID,
            'secret_key' => static::SECRET_KEY,
            'amount' => $amount,
            'system' => $system,
            'wallet' => $wallet
        ];
            
        $ch = curl_init('https://xmpay.one/api/createWithdraw');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);
        return $data;
    }

    public function verifyHash($request): bool
    {
        $hash = hash('sha256', $request->shop_id . $request->amount . static::SECRET_KEY . $request->id);
        if($hash != $request->hash) {
            return false;
        }

        return true;
    }
}