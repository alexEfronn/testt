<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jackpot extends Model
{
    protected $fillable = [
        'winner_id',
        'winner_ticket',
        'random',
        'status'
    ];
}
