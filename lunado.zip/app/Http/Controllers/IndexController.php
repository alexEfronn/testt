<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Auth;
use App\User;
use App\ReferralProfit;

class IndexController extends Controller
{
    public function index()
    {
        if(
            $this->user &&
            $this->user->referral_use &&
            !$this->user->referral_send &&
            $this->user->tg_bonus_use &&
            User::where('used_ip', $this->getIp())
                ->orWhere('created_ip', $this->getIp())
                ->count() <= 1
        ) {
            ReferralProfit::create([
                'user_id' => $this->user->id,
                'ref_id' => $this->user->referral_use,
                'amount' => $this->config->ref_price
            ]);
            
            User::where('id', $this->user->referral_use)->update([
                'balance' => DB::raw('balance + ' . $this->config->ref_price),
                //'wager' => DB::raw('wager + ' . $this->config->ref_price * 2),
            ]);

            $this->user->update([
                'referral_send' => 1
            ]);
        }
        
        return view('app');
    }

    public function getGroupVK()
    {
        return \App\Setting::query()->find(1)->vk_url;
    }

    public function getInfo()
    {
        return [
            'ref_percent' => \App\Setting::query()->find(1)->ref_perc
        ];
    }

    public function initConfig()
    {
        return [
            'recaptcha_site' => $this->config->recapctha_site,
            'vk_support_url' => $this->config->vk_support_url,
            'vk_url' => $this->config->vk_url,
            'tg_channel' => $this->config->tg_channel,
            'tg_bot' => $this->config->tg_bot
        ];
    }

    public function getBalance()
    {
        if(!$this->user) return;

        return [
            'balance' => $this->user->balance
        ];
    }
}
