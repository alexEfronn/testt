<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\User;
use App\Message;
use App\Promocode;
use DB;
use Cache;

class ChatController extends Controller
{
    const NEW_MESSAGE    = 'new.message';
    const DELETE_MESSAGE = 'delete.message';
    const CLEAR_MESSAGE  = 'clear.message';

    public function __construct()
    {
        parent::__construct();
        DB::connection()->getPdo()->exec('SET TRANSACTION ISOLATION LEVEL READ COMMITTED');
    }

    public function init()
    {
        $messages = Message::query()
            ->where('user_id', '!=', 0)
            ->orderBy('messages.id', 'asc')
            ->join('users', 'users.id', '=', 'messages.user_id')
            ->select(
                'users.photo_200 as avatar', 
                'users.username', 
                'users.is_admin',
                'users.is_moderator',
                DB::raw('DATE_FORMAT(messages.created_at, "%H.%i") as time'),
                'messages.*'
            )
            ->limit(20)
            ->get();
                
        return $messages;
    }

    public function send(Request $request)
    {
        if(Cache::has('new.message.' . $this->user->id) && (!$this->user->is_admin || !$this->user->is_moderator)) {
            return [
                'error' => true,
                'message' => 'Не спешите'
            ];
        }
        $validator = Validator::make($request->all(), [
            'text' => 'required|min:1|max:200'
        ]);

        if($validator->fails()) {
            return [
                'error' => true,
                'message' => $validator->errors()->first()
            ];
        }

        if($this->user->chat_ban >= time()) {
            return [
                'error' => true,
                'message' => 'Вы заблокированы в чате до ' . date('Y-m-d H:i:s', $this->user->chat_ban) . '<br>Причина: ' . $this->user->chat_ban_reason
            ];
        }

        // команды

        if($request->text == '/clear' && ($this->user->is_admin || $this->user->is_moderator)) {
            Message::query()->delete();
            $this->redis->publish(self::CLEAR_MESSAGE, json_encode([]));
            return [
                'success' => true
            ];
        }

        $data = [
            'user_id' => $this->user->id,
            'text' => $request->text
        ];

        Cache::put('new.message.' . $this->user->id, '', 2);

        $message = Message::create($data);

        Message::where('id', '<=', $message->id - 20)->delete();

        $this->redis->publish(self::NEW_MESSAGE, json_encode([
            'id' => $message->id,
            'user_id' => $this->user->id,
            'username' => $this->user->username,
            'avatar' => $this->user->photo_200,
            'time' => date('H:i'),
            'text' => $request->text,
            'role' => $this->getRole()
        ]));
        
        return [
            'success' => true
        ];
    }

    // moderator or admin

    public function delete(Request $request)
    {
        if(!$this->user->is_moderator && !$this->user->is_admin) {
            return [
                'error' => true,
                'message' => 'Нет доступа'
            ];
        }

        $message = Message::find($request->id);

        if(!$message) {
            return [
                'error' => true,
                'message' => 'Сообщение уже удалено'
            ];
        }

        $message->delete();
        $this->redis->publish(self::DELETE_MESSAGE, json_encode([
            'id' => $request->id
        ]));

        return [
            'success' => true
        ];
    }

    public function ban(Request $request)
    {
        if(!$this->user->is_moderator && !$this->user->is_admin) {
            return [
                'error' => true,
                'message' => 'Нет доступа'
            ];
        }

        $message = Message::find($request->id);

        if(!$message) {
            return [
                'error' => true,
                'message' => 'Сообщение уже удалено'
            ];
        }

        if(mb_strlen($request->reason) > 12) {
            return [
                'error' => true,
                'message' => 'Причина должна быть в пределах 12 символов'
            ];
        }

        if(!$message->user_id) {
            return [
                'error' => true,
                'message' => 'Нельзя заблокировать бота'
            ];
        }

        $user = User::find($message->user_id);
        $user->chat_ban = time() + 60 * $request->time;
        $user->chat_ban_reason = $request->reason;
        $user->save();
        
        $message->delete();
        $this->redis->publish(self::DELETE_MESSAGE, json_encode([
            'id' => $request->id,
            'type' => 'ban'
        ]));

        return [
            'success' => true
        ];
    }

    public function generatePromocode()
    {
        $activation = 15;
        $amount = 2;

        $promocode = \Str::random(6);
        $text = 'Промокод: ' . $promocode;

        Promocode::create([
            'name' => $promocode,
            'sum' => $amount,
            'activation' => $activation,
            'type' => 'balance'
        ]);
        
        $data = [
            'user_id' => 0,
            'text' => $text
        ];

        $message = Message::create($data);

        $this->redis->publish(self::NEW_MESSAGE, json_encode([
            'id' => $message->id,
            'user_id' => 0,
            'username' => 'Elon Musk',
            'avatar' => 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/Elon_Musk_Royal_Society_%28crop2%29.jpg/274px-Elon_Musk_Royal_Society_%28crop2%29.jpg',
            'time' => date('H:i'),
            'text' => $text,
            'role' => 'admin'
        ]));

        return 1;
    }

    public function banlist()
    {
        if(!$this->user->is_admin && !$this->user->is_moderator) return;

        $users = User::query()
            ->where('chat_ban', '>', time())
            ->select(
                'users.id', 
                'users.photo_200', 
                'users.username', 
                'users.chat_ban', 
                'users.chat_ban_reason'
            )
            ->get();

        return $users;
    }

    public function unmute(Request $request)
    {
        if(!$this->user->is_moderator && !$this->user->is_admin) {
            return [
                'error' => true,
                'message' => 'Нет доступа'
            ];
        }

        $user = User::find($request->user_id);

        if(!$user) {
            return [
                'error' => true,
                'message' => 'Пользователь не найден'
            ];
        }

        $user->chat_ban = 0;
        $user->chat_ban_reason = null;
        $user->save();

        return [
            'success' => true,
            'text' => 'Пользователь ' . $user->username . ' разблокирован'
        ];
    }

    private function getRole()
    {
        if($this->user->is_admin) {
            return 'admin';
        }

        if($this->user->is_moderator) {
            return 'moderator';
        }

        return 0;
    }
}
