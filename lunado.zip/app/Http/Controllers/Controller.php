<?php

namespace App\Http\Controllers;

use App\User;
use App\Setting;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Cookie;
use App\Http\Middleware\EncryptCookies;
use Illuminate\Support\Facades\Redis;
use Auth;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    protected $config;
    protected $auth;
    protected $token;
    protected $OPERATOR_ID = 20854;
    protected $YT_OPERATOR_ID = 20854;

    protected $PROVIDERS = [
        "Netent",
        "Play'n GO",
        "Pragmatic Play"
    ];

    public function __construct()
    {
        $this->config = Setting::query()->find(1);
        $this->redis = Redis::connection();
        
        if($this->auth && $this->auth->is_youtuber) {
            $this->OPERATOR_ID = $this->YT_OPERATOR_ID;
        }

        view()->share('settings', $this->config);
        $this->middleware(function ($request, $next) {
            $this->user = Auth::User();
            view()->share('u', $this->user);
            return $next($request);
        });
    }

    public function curl($url) 
    {
		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $res = curl_exec($ch);
        curl_close($ch);
        return json_decode($res, true);
	}

    public function getIp() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif(!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        return $ip;
    }

    public function isMulti($user_id)
    {
        $user = User::find($user_id);

        if(User::where('created_ip', $user->created_ip)->count() > 3) {
            return true;
        }

        return false;
    }
}
