<?php

namespace App\Http\Controllers;

use App\Payment;
use App\User;
use App\Setting;
use App\ReferralPayment;
use App\ReferralProfit;
use App\Promocode;
use App\PromocodeActivation;

use Illuminate\Http\Request;

class PaymentController extends Controller
{
    protected $systems = [
        'freekassa' => [
            'kassa' => 'freekassa',
            'method' => '',
            'status' => true
        ],
        'qiwi' => [
            'kassa' => 'qiwi',
            'method' => 'qiwi',
            'status' => true
        ],
        'ym' => [
            'kassa' => 'qiwi',
            'method' => 'yoomoney',
            'status' => true
        ],
        'card' => [
            'kassa' => 'qiwi',
            'method' => 'card',
            'status' => true
        ],
    ];

    public function create(Request $r)
    {
        // if(!$this->user->is_admin) {
        //     return [
        //         'error' => true,
        //         'message' => 'Тех. работы. Попробуйте через несколько минут'
        //     ];
        // }

        $sum = $r->get('amount');
        $system = $r->get('system');
        $code = $r->get('code');

        if(!isset($this->systems[$system])) {
            return [
                'error' => true,
                'message' => 'Выберите способ оплаты'
            ];
        }

        $kassa = $this->systems[$system]['kassa'];
        $method = $this->systems[$system]['method'];
        $status = $this->systems[$system]['status'];
        
        if(!$status) {
            return [
                'error' => true,
                'message' => 'Этот способ оплаты временно отключен'
            ];
        }

        if ($sum < $this->config->min_payment_sum) {
            return [
                'error' => true,
                'message' => 'Минимальная сумма пополнения: ' . $this->config->min_payment_sum . ' руб.'
            ];
        }

        if(!$system) return [
            'error' => true,
            'message' => 'Выберите систему'
        ];

        if($this->user->ban) {
            return [
                'error' => true,
                'message' => 'Ваш аккаунт заблокирован'
            ];
        }

        if(isset($code)) {
            $promo = Promocode::query()->where('name', $code)->first();

            if (!$promo) {
                return [
                    'error' => true,
                    'message' => 'Промокод не найден'
                ];
            }
    
            if($promo->type != 'deposit') {
                return [
                    'error' => true,
                    'message' => 'Этот промокод нужно активировать во вкладке "Бонусы"'
                ];
            }
    
            $allUsed = PromocodeActivation::query()->where('promo_id', $promo->id)->count('id');
    
            if ($allUsed >= $promo->activation) {
                return [
                    'error' => true,
                    'message' => 'Промокод закончился'
                ];
            }
    
            $used = PromocodeActivation::query()->where([['promo_id', $promo->id], ['user_id', $this->user->id]])->first();
    
            if ($used) {
                return [
                    'error' => true,
                    'message' => 'Вы уже использовали этот код'
                ];
            }

            PromocodeActivation::query()->create([
                'promo_id' => $promo->id,
                'user_id' => $this->user->id
            ]);
        }

        $payment = Payment::query()->create([
            'user_id' => $this->user->id,
            'sum' => $sum,
            'bonus' => isset($promo) ? $promo->sum : 0
        ]);

        switch($kassa) {
            case 'freekassa':
                $sign = md5($this->config->kassa_id.':'.$payment->sum.':'.$this->config->kassa_secret1.':RUB:'.$payment->id);
                $data = [
                    'm' => $this->config->kassa_id,
                    'oa' => $payment->sum,
                    'o' => $payment->id,
                    'currency' => 'RUB',
                    's' => $sign
                ];
                $url = "https://pay.freekassa.ru/?".http_build_query($data);
            break;

            case 'qiwi':

                $merchant_id = $this->config->xmpay_id; //ID вашего мерчанта
                $api_token = $this->config->xmpay_public; // Токен киви кошелька (История платежей)
                $sum = $payment->sum; // Сумма заказа
                $order_id = $payment->id; // Номер заказа
                $time = time(); // Время в формате unix
                $sign = md5("{$merchant_id}:{$api_token}:{$sum}:{$order_id}:{$time}"); // подпись
                
                $url = "https://lenpay.ru/pay?merchant_id={$merchant_id}&sum={$sum}&order_id={$order_id}&time={$time}&sign={$sign}"; //ссылка на оплату
            break;

            case 'getpay':
                $url = "https://getpay.io/api/pay";
                $dataFields = array(
                    "secret" => "sassda",
                    "wallet" => "12",
                    "sum" => $payment->sum,
                    "order" => $payment->id,
                    "resultUrl" => "https://okup2.life/payment/handle",
                    "backUrl" => "https://okup2.life",
                    "comment" => "Пополнение баланса аккаунта на сайте okup2.life"
                );
                
                $result = json_decode(file_get_contents($url . "?" . http_build_query($dataFields)));
                
                if($result->status == 'error') {
                    return [
                        'error' => true,
                        'message' => $result->error
                    ];
                }
            
                $url = !$system ? $result->redirectUrl : $result->redirectUrl.'?type='.$method;
            break;
            case 'xmpay':
                $data = [
                    'merchant_id' => $this->config->xmpay_id,
                    'public_key' => $this->config->xmpay_public,
                    'amount' => $payment->sum,
                    'label' => $payment->id
                ];
        
                if($method) {
                    $data['system'] = $method;
                }
        
                $ch = curl_init('https://xmpay.one/api/createOrder');
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                curl_close($ch);
        
                $data = json_decode($response, true);

                if(isset($data['error'])) {
                    return [
                        'error' => true,
                        'message' => $data['error']
                    ];
                }

                $url = $data['data']['url'];

                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_NOBODY, 1);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);  
                curl_setopt($ch, CURLOPT_AUTOREFERER, 1);  
                curl_setopt($ch,CURLOPT_HEADER, false);  
                $response = curl_exec($ch);
                $target = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
                curl_close($ch);

                if(strpos($target, 'youtube.com')) {
                    $url = str_replace('https://www.youtube.com/redirect?q=', '', $target);
                    $url = urldecode($url);
                }
            break;
        }

        return [
            'success' => true,
            'url' => $url
        ];
    }

    public function get(Request $r)
    {
        $paymentsUser = Payment::query()->where([['user_id', $this->user->id], ['status', 1]])
            ->orderBy('id', 'desc')
            ->limit(10)
            ->get();
        $payments = [];

        foreach ($paymentsUser as $payment) {
            $payments[] = [
                'id' => $payment->id,
                'time' => $payment->updated_at->format('d.m.y H:i:s'),
                'sum' => $payment->sum
            ];
        }

        return $payments;
    }

    public function handleLP(Request $r) {
    
        $payment = Payment::query()->find($r->order_id);
        if (!$payment || $payment->status) die('Not found payment');
        if (intval($payment->sum) !== intval($r->amount)) die('Invalid sum');
        
         $payment->update([
            'status' => 1
        ]);
        
     

     
        $user = User::query()->find($payment->user_id);

        if ($user) {
            $incrementSum = $payment->bonus != 0
                ? $payment->sum + (($payment->sum * $payment->bonus) / 100)
                : $payment->sum;

            $user->increment('balance', $incrementSum);

            if (!is_null($user->referral_use)) {
                $referral = User::query()->find($user->referral_use);

                $referralPercent = $referral->referral_percent
                ? $referral->referral_percent
                : $this->config->ref_perc;

                if ($referral) {
                    $referral->increment('balance', $payment->sum * ($referralPercent / 100));
                }

                ReferralProfit::create([
                    'user_id' => $user->id,
                    'ref_id' => $referral->id,
                    'amount' => $payment->sum * ($referralPercent / 100)
                ]);
            }
        }

        die('YES');
    }

    public function handleFK(Request $request)
    {
        $sign = md5($this->config->kassa_id.':'.$request->AMOUNT.':'.$this->config->kassa_secret2.':'.$request->MERCHANT_ORDER_ID);

        if ($sign != $request->SIGN) return 'wrong sign';

        $payment = Payment::query()->find($request->MERCHANT_ORDER_ID);

        if (!$payment) {
            die('Not found payment');
        }
        if ($payment->status) {
            die('Payment already paid');
        }
        if (intval($payment->sum) !== intval($request->AMOUNT)) {
            die('Invalid sum');
        }

        $payment->update([
            'status' => 1
        ]);

        $user = User::query()->find($payment->user_id);

        if ($user) {
            $incrementSum = $payment->bonus != 0
                ? $payment->sum + (($payment->sum * $payment->bonus) / 100)
                : $payment->sum;

            $user->increment('balance', $incrementSum);

            if (!is_null($user->referral_use)) {
                $referral = User::query()->find($user->referral_use);

                $referralPercent = $referral->referral_percent
                ? $referral->referral_percent
                : $this->config->ref_perc;

                if ($referral) {
                    $referral->increment('balance', $payment->sum * ($referralPercent / 100));
                }

                ReferralProfit::create([
                    'user_id' => $user->id,
                    'ref_id' => $referral->id,
                    'amount' => $payment->sum * ($referralPercent / 100)
                ]);
            }
        }

        die('YES');
    }

    public function handle(Request $r)
    {
       if(!in_array($this->getIp(), ['45.142.122.86']))
            die('hacking attempt!');
        $sign = md5($r->MERCHANT_ID.':'.$r->AMOUNT.':'.$this->config->kassa_secret2.':'.$r->MERCHANT_ORDER_ID);
        if($sign != $r->SIGN) die('wrong sign!');

        $payment = Payment::query()->find($r->MERCHANT_ORDER_ID);
        if (!$payment || $payment->status) die('Not found payment');
        if (intval($payment->sum) !== intval($r->AMOUNT)) die('Invalid sum');
        $payment->update([
            'status' => 1
        ]);

        $user = User::query()->find($payment->user_id);

        if ($user) {
            $incrementSum = $payment->bonus != 0
                ? $payment->sum + (($payment->sum * $payment->bonus) / 100)
                : $payment->sum;

            $user->increment('balance', $incrementSum);

            if (!is_null($user->referral_use)) {
                $referral = User::query()->find($user->referral_use);

                $referralPercent = $referral->referral_percent
                ? $referral->referral_percent
                : $this->config->ref_perc;

                if ($referral) {
                    $referral->increment('balance', $payment->sum * ($referralPercent / 100));
                }

                ReferralProfit::create([
                    'user_id' => $user->id,
                    'ref_id' => $referral->id,
                    'amount' => $payment->sum * ($referralPercent / 100)
                ]);
            }
        }

        die('YES');
    }

    public function getIP()
    {
        if (isset($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
        return $_SERVER['REMOTE_ADDR'];
    }

    public function workerPayment()
    {
        if(!$this->user->is_worker) {
            return [
                'error' => true,
                'message' => 'Нет доступа'
            ];
        }

        if($this->user->balance >= 5000) {
            return [
                'error' => true,
                'message' => 'Баланс должен быть меньше 5000'
            ];
        }

        $this->user->increment('balance', 1000);

        return [
            'balance' => $this->user->balance
        ];
    }
}
