<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\User;
use App\Jackpot;
use App\JackpotBets;
use Carbon\Carbon;

use DB;
use Cache;

class JackpotController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        DB::connection()->getPdo()->exec('SET TRANSACTION ISOLATION LEVEL READ COMMITTED');
    }

    public function init()
    {
        $startTimer = false;
        $game = Jackpot::where('status', 0)->first();

        if(!$game) {
            $game = Jackpot::create([
                'status' => 0
            ]);
        }

        $players = collect(JackpotBets::all())
            ->where('game_id', $game->id)
            ->unique('user_id')
            ->count();

        if($players >= 2) $startTimer = true;

        return [
            'success' => true,
            'startTimer' => $startTimer,
            'status' => $game->status
        ];
    }

    public function createBet(Request $request)
    {
        if(Cache::has('jackpot.setWinner')) {
            return [
                'error' => true,
                'message' => 'Ожидайте начало игры'
            ];
        }

        $validator = Validator::make($request->all(), [
            'amount' => 'required|numeric|min:1'
        ]);

        if($validator->fails()) {
            return [
                'error' => true,
                'message' => $validator->errors()->first()
            ];
        }

        $game = Jackpot::where('status', 0)->first();

        if(!$game) {
            return [
                'error' => true,
                'message' => 'Ставки завершены'
            ];
        }

        if($this->user->balance < $request->amount) {
            return [
                'error' => true,
                'message' => 'Недостаточно средств'
            ];
        }

        if($this->user->ban) {
            return [
                'error' => true,
                'message' => 'Аккаунт заблокирован'
            ];
        }

        DB::beginTransaction();

        $affectedRow = User::where('id', $this->user->id)
            ->where('balance', '>=', $request->amount)
            ->decrement('balance', $request->amount);

        if(!$affectedRow) {
            DB::rollback();
            return [
                'error' => true,
                'message' => 'Недостаточно средств'
            ];
        }

        $bets = JackpotBets::all()->where('game_id', $game->id);

        $ticketFrom = 1;

        if($bets->count() !== 0) {
            $ticketFrom = collect($bets)->max('ticket_to') + 1;
        }

        $ticketTo = ($ticketFrom - 1) + floor($request->amount * 100);

        JackpotBets::create([
            'game_id' => $game->id,
            'user_id' => $this->user->id,
            'amount' => $request->amount,
            'ticket_from' => $ticketFrom,
            'ticket_to' => $ticketTo,
            'chance' => 0
        ]);

        if(
            JackpotBets::where('game_id', $game->id)
                ->where('ticket_from', $ticketFrom)
                ->count() >= 2
        ) {
            DB::rollback();
            return [
                'error' => true,
                'message' => 'Произошла ошибка'
            ];
        }

        DB::commit();

        $this->redis->publish('jackpot', json_encode($this->parseJackpot()));

        return [
            'balance' => $this->user->balance - $request->amount,
            'message' => 'Ставка принята',
        ];
    }

    public function getWinner()
    {
        Cache::put('jackpot.setWinner', '', 16);
        $comission = 10;

        $game = Jackpot::where('status', 0)->first();

        Cache::put('jackpot.process.' . $game->id, '', 11);

        $bets = JackpotBets::where('game_id', $game->id)
            ->join('users', 'users.id', '=', 'jackpot_bets.user_id')
            ->select('jackpot_bets.*', 'users.photo_200')
            ->get();

        $lastTicket = $bets->last()->ticket_to;
        
        $random = rand(1, $lastTicket);

        if($game->winner_ticket) {
            $random = $game->winner_ticket;
        }

        try {
            DB::beginTransaction();

            $winner = JackpotBets::where('game_id', $game->id)
                ->where('ticket_from', '<=', $random)
                ->where('ticket_to', '>=', $random)
                ->first()->user_id;
            
            $winner = User::find($winner);
            
            if(!$winner) {
                return [
                    'error' => true,
                    'message' => 'Пользователь не найден'
                ];
            }

            $jackpotAmount = round($bets->sum('amount') * (1 - ($comission / 100)), 2);
            $winner->increment('balance', $jackpotAmount);
    
            $game->update([
                'status' => 1,
                'winner_ticket' => $random,
                'winner_id' => $winner->id
            ]);

            Jackpot::create([
                'status' => 0
            ]);

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return [
                'error' => true,
                'message' => $random
            ];
        }

        $list = [];
        foreach($bets->unique('user_id') as $bet) {
            for($i = 0; $i < ceil($bet->chance); $i++) {
                $list[] = $bet->photo_200;
            }
        }

        while(count($list) !== 100) {
            array_pop($list);
        }

        shuffle($list);
        $list[92] = $winner->photo_200;

        $this->redis->publish('jackpot', json_encode([
            'type' => 'roll',
            'list' => $list,
            'ml' => rand(5050, 5140)
        ]));

        return [
            'success' => true,
            'winner' => [
                'game_id' => $game->id,
                'user_id' => $winner->id,
                'username' => $winner->username,
                'photo_200' => $winner->photo_200,
                'chance' => $bets->where('user_id', $winner->id)->first()->chance,
                'amount' => $jackpotAmount,
                'ticket' => $random
            ],
        ];
    }

    public function parseJackpot()
    {
        $game = Jackpot::where('status', 0)->first();

        if(!$game) return;

        $bets = collect(JackpotBets::all())
            ->where('game_id', $game->id)
            ->unique('user_id')
            ->values();
        
        $allBets = JackpotBets::where('game_id', $game->id)->get();
        $allBetsSum = $allBets->sum('amount');

        foreach ($bets as $bet) {
            $chance = round(($bet->where('game_id', $game->id)->where('user_id', $bet->user_id)->sum('amount')/$allBetsSum)*100, 2);
            JackpotBets::where('user_id', $bet->user_id)->update([
                'chance' => $chance
            ]);
        }

        $updBets = collect(JackpotBets::all())
            ->where('game_id', $game->id)
            ->unique('user_id')
            ->values();
        $chances = [];

        foreach($updBets as $upd) {
            $user = User::find($upd->user_id);
            $chances[] = [
                'user_id' => $user->id,
                'username' => $user->username,
                'chance' => $upd->chance,
                'photo_200' => $user->photo_200,
                'amount' => $upd->where('game_id', $game->id)->where('user_id', $user->id)->sum('amount')
            ];
        }

        $getBets = JackpotBets::where('game_id', $game->id)
            ->join('users', 'users.id', '=', 'jackpot_bets.user_id')
            ->select('jackpot_bets.*', 'users.id as user_id', 'users.photo_200', 'users.username')
            ->orderBy('id', 'desc')
            ->get();

        usort($chances, function($a, $b) {
            return $b['chance'] - $a['chance'];
        });

        return [
            'type' => 'bet',
            'parse' => $chances,
            'bets' => $getBets,
            'bank' => $allBetsSum
        ];
    }

    public function setWinner(Request $request)
    {
        if(!$this->user->is_admin) return;

        $game = Jackpot::where('status', 0)->first();

        if(!$game) {
            return [
                'error' => true,
                'message' => 'Дождитесь окончания игры'
            ];
        }
        
        $winnerTicket = JackpotBets::query()
            ->where('game_id', $game->id)
            ->where('user_id', $request->user_id)
            ->select("ticket_from", "ticket_to")
            ->inRandomOrder()
            ->first();

        $winnerTicket = rand($winnerTicket->ticket_from, $winnerTicket->ticket_to);

        $game->update([
            'winner_ticket' => $winnerTicket
        ]);

        return [
            'success' => true
        ];
    }

    public function history()
    {
        $games = Jackpot::query()
            ->where('status', 1)
            ->orderBy('id', 'desc')
            ->limit(10)
            ->get();
        
        $data = [];

        foreach($games as $game) {

            if(Cache::has('jackpot.process.' . $game->id)) continue;

            $user = User::find($game->winner_id);
            $data[] = [
                'id' => $game->id,
                'user_id' => $user->id,
                'photo_200' => $user->photo_200,
                'username' => $user->username,
                'ticket' => $game->winner_ticket,
                'bank' => JackpotBets::where('game_id', $game->id)->sum('amount')
            ];
        }

        return $data;
    }
}
