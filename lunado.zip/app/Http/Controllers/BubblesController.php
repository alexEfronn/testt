<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Redis;

use App\User;
use App\Mine;
use App\Setting;
use App\Profit;
use Auth;
use DB;

class BubblesController extends Controller
{
    protected $profit;

    public function __construct()
    {
        parent::__construct();
        $this->profit = Profit::first();
    }

    public function play(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'amount' => 'required|numeric|min:1',
            'chance' => 'required|numeric|min:0.01|max:95',
        ]);

        if($validator->fails()) {
            return [
                'error' => true,
                'message' => $validator->errors()->first()
            ];
        }

        if($this->user->ban) {
            return [
                'error' => true,
                'message' => 'Ваш аккаунт заблокирован'
            ];
        }

        $random = rand(0, 999999);
        $isWin = false;
        $win = round((100 / $request->chance) * $request->amount, 2);
        $coef = 0;

        $goal = round(100 / $request->chance, 2);
        $x = round(1000000 / ($random + 1), 2);

        try {
            DB::beginTransaction();

            $user = User::where('id', $this->user->id)
                ->where('balance', '>=', $request->amount)
                ->first();
            
            if(!$user) {
                return [
                    'error' => true,
                    'message' => 'Недостаточно средств'
                ];
            }

            $this->user->decrement('balance', $request->amount);
            $this->user->decrement('wager', $request->amount);
            $this->user->decrement('bubbles', $request->amount);
    
            if($this->user->wager < 0) $this->user->update([
                'wager' => 0
            ]);

            if($x >= $goal) {
                $isWin = true;
            }

            if($this->config->antiminus == 1 && !$this->user->is_youtuber) {
                if($win - $request->amount > $this->profit->bank_bubbles && $isWin) {
                    $x = round(rand(100, $goal * 100 - 1) / 100, 2);
                    $isWin = false;
                }
            }

            if($isWin) {
                $this->user->increment('balance', $win);
                $this->user->increment('bubbles', $win);

                if($this->config->antiminus == 1 && !$this->user->is_youtuber) {
                    $this->profit->update([
                        'bank_bubbles' => $this->profit->bank_bubbles - ($win - $request->amount),
                    ]);
                }
            } else {
                if(!$this->user->is_youtuber) {
                    $this->profit->update([
                        'bank_bubbles' => $this->profit->bank_bubbles + ($request->amount / 100) * (100 - $this->profit->comission),
                        'earn_bubbles' => $this->profit->earn_bubbles + ($request->amount / 100) * $this->profit->comission
                    ]);
                }
            }

            DB::commit();

        } catch (\Exception $e) {
            DB::rollback();
            return [
                'error' => true,
                'message' => $e->getMessage()
            ];
        }

        Redis::publish('newGame', json_encode([
            'id' => rand(10000, 99999999999),
            'user_id' => $this->user->id,
            'type' => 'bubbles',
            'username' => $this->user->username,
            'amount' => $request->amount,
            'coeff' => round($win / $request->amount, 2),
            'result' => $isWin ? $win : 0
        ]));

        return [
            'result' => $isWin,
            'multiplier' => $x,
            'total' => $win,
            'balance' => $this->user->balance
        ];
    }
}