<?php

namespace App\Http\Controllers;

use App\User;
use App\Slots;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Exception;

class SlotsController extends Controller
{
    public function __construct() 
    {
		parent::__construct();
        $this->user = $this->auth;
    }

    public function getGames(Request $r) 
    {
        $search = $r->search;
        $page = $r->page;
        $show = 10;

        if($search && !ctype_alnum($search)) {
            return [
                'error' => true,
                'message' => 'Название может содержать только английские буквы и цифры'
            ];
        }

        $list = [];

        $games = Slots::query()->offset($show * ($page - 1))
            ->limit($show)
            ->orderBy('id', 'desc')
            ->orderBy('priority', 'desc')
            ->where('show', '=', 1);
            
        $games = !$search 
            ? $games->get() 
            : $games->where('title', 'like', '%' . $search . '%')->orWhere('provider', 'like', '%' . $search . '%')->get();
    
        foreach($games as $game) {
            array_push($list, [
                'game_id' => $game->game_id,
                'title' => $game->title,
                'preview' => '/assets/img/slots/' . str_replace([" ", "The"], "", $game->title) . '.jpg',
                'provider' => $game->provider
            ]);
        }

        $lastPage = Slots::where('show', '=', 1)->count() - $show * $page >= 1
            ? false
            : true;

        return [
            'success' => true,
            'games' => $list,
            'lastPage' => $lastPage
        ];
    }

    public function getGameURI(Request $r) 
    {
        $gameId = $r->gameId;

        if(!$this->user) return [
            'error' => true,
            'message' => 'Вы не авторизованы'
        ];

        if($this->user->ban) return [
            'error' => true,
            'message' => 'Ваш аккаунт заблокирован'
        ];

        if(!$this->user->api_token) return [
            'error' => true,
            'message' => 'Отсутствует api_token. Обновите страницу'
        ];

        $url = "https://int.apiforb2b.com/gamesbycode/{$gameId}.gamecode?operator_id={$this->OPERATOR_ID}&language=ru&user_id={$this->user->id}&auth_token={$this->user->api_token}&currency=RUB&home_url=https://{$_SERVER['HTTP_HOST']}/slots";

        return [
            'success' => true,
            'url' => $url
        ];
    }

    public function callback(Request $request) 
    {
        if(!in_array($_SERVER['REMOTE_ADDR'], ['190.2.132.67'])) return 'hacking attempt!';
        try
        {
            switch($request->api) 
            {
                case 'do-auth-user-ingame':
                    $data = app('App\Http\Controllers\Slots\AuthController')->initAuth($request);
                    return json_encode($data);
                break;

                case 'do-debit-user-ingame':
                    $data = app('App\Http\Controllers\Slots\DebitController')->debit($request);
                    return json_encode($data);
                break;
    
                case 'do-credit-user-ingame':
                    $data = app('App\Http\Controllers\Slots\CreditController')->credit($request);
                    return json_encode($data);
                break;
            
                case 'do-rollback-user-ingame':
                    $data = app('App\Http\Controllers\Slots\RollbackController')->rollback($request);
                    return json_encode($data);
                break;        
    
                case 'do-get-features-user-ingame':
                    $data = app('App\Http\Controllers\Slots\FeaturesController')->getFeatures($request);
                    return json_encode($data);
                break;
    
                case 'do-activate-features-user-ingame':
                    $data = app('App\Http\Controllers\Slots\FeaturesController')->activateFeatures($request);
                    return json_encode($data);
                break;	

                case 'do-update-features-user-ingame':
                    $data = app('App\Http\Controllers\Slots\FeaturesController')->updateFeatures($request);
                    return json_encode($data);
                break;

                case 'do-end-features-user-ingame':
                    $data = app('App\Http\Controllers\Slots\FeaturesController')->endFeatures($request);
                    return json_encode($data);
                break;
    
                default :
                    throw new Exception("Unknown api");
            }
        }
        catch (Exception $e)
        {
            $response = (object) [];
            $response->answer = (object) [];
            $response->answer->error_code = 1;
            $response->answer->error_description = $e->getMessage();
            $response->answer->timestamp = '"'.time().'"';   
            $response->api = $request->api;
            $response->success = true;
            
            return json_encode($response);       
        }
    }
}
