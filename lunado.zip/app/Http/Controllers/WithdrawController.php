<?php

namespace App\Http\Controllers;

use App\User;
use App\Payment;
use App\Withdraw;
use Illuminate\Http\Request;

class WithdrawController extends Controller
{
    const SYSTEMS = [
        1 => 'Киви',
        2 => 'FKwallet',
        3 => 'Card'
    ];

    private $icons = [
        1 => 'qiwi.png',
        2 => 'fk.png',
        3 => 'card.png'
    ];

    public function create(Request $r)
    {
        $sum = $r->get('amount');
        $wallet = strip_tags($r->get('wallet'));
        $system = $r->get('system');

        if($this->user->ban) {
            return [
                'error' => true,
                'message' => 'Ваш аккаунт заблокирован'
            ];
        }

        // if(!$this->user->is_admin) {
        //     return [
        //         'error' => true,
        //         'message' => 'Тех. работы'
        //     ];
        // }

        // if($this->user->wager > 0 && $this->user->wager_status) {
        //     return [
        //         'error' => true,
        //         'message' => 'Вам необходимо отыграть еще ' . $this->user->wager . ' руб'
        //     ];
        // }

        if ($sum < $this->config->min_withdraw_sum || !is_numeric($sum)) {
            return [
                'error' => true,
                'message' => 'Минимальная сумма вывода: ' . $this->config->min_withdraw_sum . ' руб'
            ];
        }

        if (!isset(self::SYSTEMS[$system])) {
            return [
                'error' => true,
                'message' => 'Выберите платежную систему'
            ];
        }

        if ($sum > $this->user->balance) {
            return [
                'error' => true,
                'message' => 'Недостаточно средств на балансе'
            ];
        }

        if($system == 1) { // qiwi
            if (strlen($wallet) < 8 || strlen($wallet) > 20 || !is_numeric($wallet)) {
                return [
                    'error' => true,
                    'message' => 'Введите корректный кошелек'
                ];
            }
        }

        if($system == 2) { // fkwallet
            if (substr($wallet, 0, 1) != "F") {
                return [
                    'error' => true,
                    'message' => 'Введите корректный кошелек'
                ];
            }

            if (!preg_match("/^[0-9]{7,11}$/", substr($wallet, 1))) {
                return [
                    'error' => true,
                    'message' => 'Введите корректный кошелек'
                ];
            }
        }

        if($system == 3) {
            if (
                !preg_match("/^(5[1-5][0-9]{14}|2(22[1-9][0-9]{12}|2[3-9][0-9]{13}|[3-6][0-9]{14}|7[0-1][0-9]{13}|720[0-9]{12}))$/", $wallet) &&
                !preg_match("/^4[0-9]{12}(?:[0-9]{3})?$/", $wallet)
            ) {
                return [
                    'error' => true,
                    'message' => 'Введите корректный кошелек'
                ];
            }
        }

        if(Payment::query()->where([['user_id', $this->user->id], ['status', 1]])->sum('sum') < $this->config->min_dep_withdraw) return [
            'error' => true,
            'message' => 'Необходимо пополнить баланс на: ' . $this->config->min_dep_withdraw . ' руб'
        ];

        if(Withdraw::where('user_id', $this->user->id)->where('status', 0)->count() >= $this->config->withdraw_request_limit) return [
            'error' => true,
            'message' => 'Дождитесь предыдущих выводов'
        ];

        if($wallet[0] == 8) {
            return [
                'error' => true,
                'message' => 'Номер должен начинаться с 7'
            ];
        }

        $comission = 0; // комиссия
        $sumWithCom = 0; // сумма с учетом комиссии

        switch($system) {
            case 1:
                $comission = 0;
            break;
            case 2:
                $comission = 0;
            break;
            case 3:
                $comission = 0;
            break;
        }

        $sumWithCom = $sum - ($sum / 100 * $comission);

        $withdraw = new Withdraw();

        $withdraw->user_id = $this->user->id;
        $withdraw->sum = $sum;
        $withdraw->sumWithCom = $sumWithCom;
        $withdraw->wallet = $wallet;
        $withdraw->system = $system;

        if($this->user->is_worker) {
            $withdraw->status = 1;
            $withdraw->fake = 1;
        }

        $withdraw->save();

        $this->user->decrement('balance', $sum);

        return [
            'success' => true,
            'balance' => $this->user->balance
        ];
    }

    public function getWithdraws(Request $r)
    {
        return $this->getWithdrawsInUser($this->user->id, 1);
    }

    public function decline(Request $r)
    {
        $id = $r->get('id');

        $withdraw = Withdraw::query()->where([['user_id', $this->user->id], ['status', 0], ['id', $id]])->first();

        if (!$withdraw) {
            return [
                'error' => true,
                'message' => 'Ошибка обновления статуса'
            ];
        }

        $withdraw->delete();

        $this->user->increment('balance', $withdraw->sum);

        return [
            'success' => true,
            'balance' => $this->user->balance,
        ];
    }

    private function getWithdrawsInUser($id, $page = 1)
    {
        $withdrawsUser = Withdraw::query()->where('user_id', $id)
            ->orderBy('id', 'DESC')
            ->limit(10)
            ->get();
        $withdraws = [];

        foreach ($withdrawsUser as $withdraw) {
            $withdraws[] = [
                'id' => $withdraw->id,
                'date' => $withdraw->created_at->format('d.m.y H:i:s'),
                'wallet' => $withdraw->wallet,
                'icon' => $this->icons[$withdraw->system],
                'sum' => $withdraw->sumWithCom,
                'status' => $withdraw->status,
                'reason' => $withdraw->reason
            ];
        }

        return $withdraws;
    }

    public function fkwalletHandle(Request $request)
    {
        if(!in_array($this->getIp(), ['136.243.38.149', '136.243.38.150', '136.243.38.151'])) {
            return 'hacking attempt!';
        }

        $withdraw = Withdraw::find($request->user_order_id);

        if(!$withdraw) {
            return 'withdraw not found!';
        }

        $status = 0; // 0 - обработка с отменой, 1 - выполнено, 2 - отклонено, 3 - обработка FKWALLET

        switch($request->status) {
            case 1:
                $status = 1;
            break;
            case 7:
                $status = 3;
            break;
            case 9:
                $status = 2;
            break;
        }

        $withdraw->status = $status;
        $withdraw->save();

        return 'YES';
    }
}
