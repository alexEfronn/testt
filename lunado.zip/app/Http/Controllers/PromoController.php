<?php

namespace App\Http\Controllers;

use App\Payment;
use App\Promocode;
use App\PromocodeActivation;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PromoController extends Controller
{
    const MIN_SUM = 0;

    public function init()
    {
        $bonusActive = true;
        $oldTime = 3600 - (Carbon::now()->timestamp - Carbon::parse($this->user->referral_use_promo)->timestamp);
        
        if((Carbon::now()->timestamp - Carbon::parse($this->user->referral_use_promo)->timestamp) < 86400 && $this->user->referral_use_promo) {
            $bonusActive = false;
        }

        return [
            'daily' => 1,
            'vk' => $this->user->vk_bonus_use ? 2 : ($this->user->vk_id && $this->user->is_vk ? 1 : 3),
            'tg' => $this->user->tg_bonus_use ? 2 : ($this->user->tg_id ? 1 : 3),
            'bonus_active' => $bonusActive,
            'remaining' => $bonusActive ? 0 : $oldTime,
            'links' => [
                'vk_url' => $this->config->vk_url,
                'tg_url' => $this->config->tg_url
            ]
        ];
    }

    public function getPromo(Request $r)
    {
        $user = $this->user;

        if (!$user->is_vk) {
            return [
                'error' => true,
                'message' => 'Привяжите аккаунт ВКонтакте'
            ];
        }

        $paymentSum = Payment::query()->where([['user_id', $user->id], ['status', 1]])->sum('sum');

        if ($paymentSum < $this->config->min_bonus_sum) {
            return [
                'error' => true,
                'message' => 'Недостаточно пополнений'
            ];
        }

        if($user->balance >= 1) {
            return [
                'error' => true,
                'message' => 'Для получения бонуса на вашем балансе должно быть меньше 1 рубля'
            ];
        }

        if($this->isMulti($this->user->id)) {
            return [
                'error' => true,
                'message' => 'У вас больше 3 мультиаккаунтов'
            ];
        }

        if ((Carbon::now()->timestamp - Carbon::parse($user->referral_use_promo)->timestamp) < 3600 && $user->referral_use_promo) {
            $oldTime = 3600 - (Carbon::now()->timestamp - Carbon::parse($user->referral_use_promo)->timestamp);

            $hour = floor($oldTime / 3600);
            $sec = $oldTime % 60;
            $min = floor(($oldTime / 60) % 60);

            if($hour < 10) $hour ='0'.$hour;
            if($sec < 10) $sec ='0'.$sec;
            if($min < 10) $min ='0'.$min;

            return [
                'error' => true,
                'message' => 'До ежечасного бонуса: ' . $hour . ':' . $min . ':' . $sec
            ];
        }

        $vk_check = $this->groupIsMember($user->vk_id);

    
        if($vk_check == 0) return [
            'error' => true,
            'message' => 'Вы не состоите в группе'
        ];

        if($vk_check == NULL) return [
            'error' => true,
            'message' => 'Произошла ошибка'
        ];

        $sum = round(mt_rand(100, 400) / 100, 2);

        $user->update([
            'balance' => $user->balance + $sum,
            'referral_use_promo' => Carbon::now()
        ]);

        return [
            'success' => true,
            'text' => 'Вы получили ' . $sum . ' руб.',
            'balance' => $this->user->balance
        ];
    }

    public function setPromo(Request $r)
    {
        $user = $this->user;
        $code = $r->get('promocode');

        $promo = Promocode::query()->where('name', $code)->first();

        if (!$promo) {
            return [
                'error' => true,
                'message' => 'Промокод не найден'
            ];
        }

        if($promo->type != 'balance') {
            return [
                'error' => true,
                'message' => 'Этот промокод нужно активировать во вкладке "Пополнить"'
            ];
        }

        $allUsed = PromocodeActivation::query()->where('promo_id', $promo->id)->count('id');

        if ($allUsed >= $promo->activation) {
            return [
                'error' => true,
                'message' => 'Промокод закончился'
            ];
        }

        if($user->balance >= 1) {
            return [
                'error' => true,
                'message' => 'Для активации промокода на вашем балансе должно быть меньше 1 рубля'
            ];
        }

        if($this->isMulti($this->user->id)) {
            return [
                'error' => true,
                'message' => 'У вас больше 3 мультиаккаунтов'
            ];
        }

        $used = PromocodeActivation::query()->where([['promo_id', $promo->id], ['user_id', $user->id]])->first();

        if ($used) {
            return [
                'error' => true,
                'message' => 'Вы уже использовали этот код'
            ];
        }

        $user->increment('balance', $promo->sum);

        PromocodeActivation::query()->create([
            'promo_id' => $promo->id,
            'user_id' => $user->id
        ]);

        return [
            'success' => true,
            'message' => 'Вы получили ' . $promo->sum . ' руб.',
            'balance' => $this->user->balance
        ];
    }

    public function vk_bonus(Request $r) {
        $user = $this->user;

        if($user->vk_bonus_use != 0) {
            return [
                'error' => true,
                'message' => 'Вы уже получали данный бонус'
            ];
        }

        if(!$user->vk_id || !$user->is_vk) {
            return [
                'error' => true,
                'message' => 'Привяжите страницу вконтакте'
            ];
        }

        $vk_check = $this->groupIsMember($user->vk_id);

        if($vk_check == 0) return [
            'error' => true,
            'message' => 'Вы не состоите в группе'
        ];
        if($vk_check == NULL) return [
            'error' => true,
            'message' => 'Произошла ошибка'
        ];

        $user->update([
            'balance' => $user->balance + $this->config->connect_bonus,
            'vk_bonus_use' => 1
        ]);

        return [
            'success' => true,
            'message' => 'Успешно',
            'balance' => $this->user->balance
        ];
    }

    public function tg_bonus()
    {
        $user = $this->user;

        if($user->tg_bonus_use != 0) {
            return [
                'error' => true,
                'message' => 'Вы уже получали данный бонус'
            ];
        }

        if(!$user->tg_id) {
            return [
                'error' => true,
                'message' => 'Привяжите аккаунт телеграм'
            ];
        }

        $user->update([
            'balance' => $user->balance + $this->config->connect_bonus,
            'tg_bonus_use' => 1
        ]);

        return [
            'success' => true,
            'message' => 'Успешно',
            'balance' => $this->user->balance
        ];
    }

    public function groupIsMember($id) {
        $user_id = $id;

        $group = $this->curl('https://api.vk.com/method/groups.isMember?group_id='.$this->config->vk_id.'&user_id='.$user_id.'&access_token='.$this->config->vk_token.'&v=5.131');

        if(isset($group['error'])) {
            $res = NULL;
        } else {
            $res = $group['response'];
        }
        return $res;
    }
}
