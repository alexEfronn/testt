<?php

namespace App\Http\Controllers;

use App\ReferralPayment;
use App\ReferralProfit;
use App\User;
use Illuminate\Http\Request;
use Carbon\Carbon;

use DB;

class ReferralController extends Controller
{
    public function init(Request $r)
    {
        $countRefs = User::query()->where('referral_use', $this->user->id)->count();
        $totalProfit = ReferralProfit::query()->where('ref_id', $this->user->id)->sum('amount');

        $referralPercent = $this->user->referral_percent
            ? $this->user->referral_percent
            : $this->config->ref_perc;

        $refs = [];

        $page = $r->page;
        $show = 5;
        $lastPage = false;

        $refslist = User::query()->offset($show * ($page - 1))
            ->leftJoin('referral_profits', function ($join) {
                $join->on('referral_profits.user_id', '=', 'users.id');
            })
            ->select(
                DB::raw('COALESCE(SUM(amount),0) as ref_profit'),
                'users.*'
            )
            ->where('users.referral_use', $this->user->id)
            ->groupBy('users.id')
            ->orderBy('ref_profit', 'DESC')
            ->limit($show)
            ->get();
        
        if($r->search !== '') {
            $refslist = User::query()->offset($show * ($page - 1))
            ->leftJoin('referral_profits', function ($join) {
                $join->on('referral_profits.user_id', '=', 'users.id');
            })
            ->select(
                DB::raw('COALESCE(SUM(amount),0) as ref_profit'),
                'users.*'
            )
            ->where('users.username', 'LIKE', '%' . $r->search . '%')
            ->where('users.referral_use', $this->user->id)
            ->groupBy('users.id')
            ->orderBy('ref_profit', 'DESC')
            ->limit($show)
            ->get();

            $countRefs = User::query()
                ->where('username', 'LIKE', '%' . $r->search . '%')
                ->where('referral_use', $this->user->id)
                ->count();
        }    

        $lastPage = $show * $page >= $countRefs
            ? true
            : false;

        foreach($refslist as $ref) {
            $refs[] = [
                'login' => $ref->username,
                'earn' => $ref->ref_profit
            ];
        }

        usort($refs, function ($a, $b) {
            return $b['earn'] - $a['earn'];
        });

        return [
            'ref_percent' => $referralPercent,
            'ref_price' => $this->config->ref_price,
            'count_refs' => $countRefs,
            'profit' => $totalProfit,
            'refs' => $refs,
            'lastpage' => $lastPage,
        ];
    }
}
