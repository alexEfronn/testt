<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Str;
use Auth;

class UserController extends Controller
{
    public function init()
    {
        if(Auth::guest()) return null;

        if(!$this->user->api_token) {
            $this->user->update([
                'api_token' => Str::random(60)
            ]);
        }

        if(!$this->user->game_token) {
            $this->user->update([
                'game_token' => Str::random(60)
            ]);
        }

        return [
            'user' => [
                'id' => $this->user->id,
                'login' => $this->user->username,
                'balance' => $this->user->balance,
                'is_worker' => $this->user->is_worker,
                'is_admin' => $this->user->is_admin,
                'is_moderator' => $this->user->is_moderator
            ]
        ];
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/');
    }
}
