<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Posts;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use DB;

class EventsController extends Controller
{
    protected $v = "5.131";
    protected $secret = "9348SZX";
    protected $key = "4c5c9cc1";
    protected $reward = 0.30;
    protected $wager = 0;

    public function handle(Request $data)
    {
        if($data->secret != $this->secret) return 'wrong secret';

        switch($data->type) {
            case 'wall_repost':
                $owner_id = $data['object']['from_id'];
                $post_id = $data['object']['copy_history'][0]['id'];

                if($post_id == 160) $this->reward = 50;

                if(!Posts::where([['post_id', $post_id], ['type', 'wall_repost'], ['owner_id', $owner_id]])->first()) {
                    Posts::create([
                        'owner_id' => $owner_id,
                        'post_id' => $post_id,
                        'type' => 'wall_repost'
                    ]);
                    User::where('vk_id', $owner_id)->increment('balance', $this->reward);
                }
            break;
            case 'confirmation':
                return $this->key;
            break;
        }
    }
}
