<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\User;
use App\Jackpot;
use App\JackpotBets;

use DB;
use Auth;

class ProfileController extends Controller
{
    public function init(Request $request)
    {
        $user = User::find($request->id);

        if(!$user) {
            return [
                'error' => true,
                'message' => 'Пользователь не найден'
            ];
        }

        $jackpot_bets = 0;
        $jackpot_win = 0;
        $vk_id = 0;

        if(!$user->privacy_hide) {
            $jackpot_bets = JackpotBets::where('user_id', $user->id)->sum('amount');
            $jackpot_win = Jackpot::where('winner_id', $user->id)
                ->join('jackpot_bets', 'jackpot_bets.game_id', '=', 'jackpots.id')
                ->sum('jackpot_bets.amount');
            $vk_id = $user->vk_id;
        }

        return [
            'id' => $user->id,
            'photo_200' => $user->photo_200,
            'username' => $user->username,
            'vk_id' => $vk_id,
            'jackpot_bets' => round($jackpot_bets, 2),
            'jackpot_win' => round($jackpot_win, 2),
            'privacy_hide' => $user->privacy_hide,
            'privacy_hide_transfer' => $user->privacy_hide_transfer
        ];
    }

    public function send(Request $request)
    {
        $receiver = User::find($request->user_id);

        if(!$receiver) {
            return [
                'error' => true,
                'message' => 'Пользователь не найден'
            ];
        }

        if($request->amount < 1 || !is_numeric($request->amount)) {
            return [
                'error' => true,
                'message' => 'Введите сумму перевода'
            ];
        }

        if($receiver->id == $this->user->id) {
            return [
                'error' => true,
                'message' => 'Нельзя переводить самому себе'
            ];
        }

        if($receiver->privacy_hide_transfer) {
            return [
                'error' => true,
                'message' => 'Пользователь не хочет получать переводы'
            ];
        }

        DB::beginTransaction();

        $affectedRow = User::query()
            ->where('id', $this->user->id)
            ->where('balance', '>=', $request->amount)
            ->decrement('balance', $request->amount);

        if(!$affectedRow) {
            DB::rollback();
            return [
                'error' => true,
                'message' => 'Недостаточно средств'
            ];
        }

        $receiver->increment('balance', $request->amount);

        $this->redis->publish('transfer', json_encode([
            'user_id' => $receiver->id,
            'amount' => $request->amount
        ]));

        DB::commit();

        return [
            'success' => true,
            'balance' => $this->user->balance - $request->amount
        ];
    }

    public function getSettings()
    {
        return [
            'social' => $this->user->privacy_hide,
            'transfer' => $this->user->privacy_hide_transfer,
            'username' => $this->user->username
        ];
    }

    public function save(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|min:3|max:12',
            'privacy_hide' => 'required|int|min:0|max:1',
            'privacy_hide_transfer' => 'required|int|min:0|max:1'
        ]);

        if($validator->fails()) {
            return [
                'error' => true,
                'message' => $validator->errors()->first()
            ];
        }

	
        $this->user->privacy_hide = $request->privacy_hide;
        $this->user->privacy_hide_transfer = $request->privacy_hide_transfer;
        $this->user->save();

        return [
            'username' => $this->user->username
        ];
    }
}