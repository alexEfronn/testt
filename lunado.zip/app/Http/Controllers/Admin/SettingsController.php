<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Setting;
use App\Profit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;

class SettingsController extends Controller
{
    public function index()
    {
        return view('admin.settings.index');
    }

    public function save(Request $r)
    {
        if ($this->config->bot_timer !== $r->get('bot_timer')) {
            Redis::publish('setNewBotTimer', $r->get('bot_timer'));
        }

        Setting::query()->find(1)->update($r->all());
        Profit::query()->find(1)->update([
            'bank_dice' => $r->bank_dice,
            'bank_mines' => $r->bank_mines,
            'bank_bubbles' => $r->bank_bubbles,
            'comission' => $r->comission
        ]);

        return redirect()->back()->with('success', 'Настройки сохранены!');
    }
}
