<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Withdraw;
use App\User;
use Illuminate\Http\Request;

class WithdrawsController extends Controller
{
    public function index()
    {
        return view('admin.withdraws.index');
    }

    public function decline(Request $request)
    {
        $withdraw = Withdraw::query()->find($request->id);

        if(!$withdraw) {
            return [
                'error' => 'Выплата отменена пользователем'
            ];
        }

        if($withdraw->status > 0) {
            return [
                'error' => 'Статус выплаты уже изменен ранее'
            ];
        }

        if($request->status == 2) {
            $user = User::where('id', $withdraw->user_id)->first();
            $user->balance += Withdraw::where('id', $request->id)->first()->sum;
            $user->save();
            $withdraw->update([
                'status' => $request->status,
                'reason' => $request->reason
            ]);
        }
    }

    public function setStatus($id, $status)
    {
        $withdraw = Withdraw::query()->find($id);

        if(!$withdraw) return redirect()->back()->with('error', 'Выплата отменена пользователем');
        if($withdraw->status > 0) return redirect()->back()->with('error', 'Статус выплаты уже изменен ранее');

        if($withdraw->sumWithCom >= 1100 || $withdraw->system == 1 || $withdraw->system == 2 || $withdraw->system == 3) {
          
            $withdraw->update([
                'status' => 1,
                'system_title' => 'freekassa'
            ]);
        } else {
            
            $withdraw->update([
                'status' => 1,
                'system_title' => 'getpay'
            ]);
        }

        
        return redirect()->back()->with('success', 'Выплата #'.$id.' отправлена!');
    }
}
