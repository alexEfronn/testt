<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\User;
use App\ReferralProfit;
use Illuminate\Http\Request;

class UsersController extends Controller
{
    public function index()
    {
        return view('admin.users.index');
    }

    public function edit($id)
    {
        $user = User::query()->find($id);
        if (!$user) {
            return redirect()->back()->with('error', 'Пользователь не найден!');
        }

        $refs = [];
        $mults = [];
        foreach (User::query()->where('referral_use', $user->id)->get() as $u) {
            $refs[] = [
                'id' => $u->id, 
                'username' => $u->username, 
                'created_at' => $u->created_at->format('d-m-Y h:i:s'), 
                'updated_at' => $u->updated_at->format('d-m-Y h:i:s'), 
                'profit' => ReferralProfit::query()->where([['user_id', $u->id], ['ref_id', $user->id]])->sum('amount')
            ];
        }
        foreach (User::query()->where('created_ip', $user->created_ip)->orWhere('used_ip', $user->used_ip)->get() as $m) {
            if($m->id != $user->id) {
                $mults[] = [
                    'id' => $m->id, 
                    'username' => $m->username, 
                    'balance' => $m->balance,
                    'created_at' => $m->created_at->format('d-m-Y h:i:s'), 
                    'updated_at' => $m->updated_at->format('d-m-Y h:i:s'), 
                    'created_ip' => $m->created_ip,
                    'used_ip' => $m->used_ip
                ];
            }
        }
        return view('admin.users.edit', compact('user', 'refs', 'mults'));
    }

    public function editPost($id, Request $r)
    {
        $user = User::query()->find($id);

        if (!$user) {
            return redirect()->back()->with('error', 'Пользователь не найден!');
        }

        if ($user->password !== $r->get('password')) {
            $user->update([
                'password' => hash('sha256', $r->get('password'))
            ]);
        }

        User::query()->find($id)->update($r->all());

        return redirect('/admin/users/edit/' . $id)->with('success', 'Данные пользователя обновлены!');
    }

    public function delete($id)
    {
        User::query()->find($id)->delete();

        return redirect()->back()->with('success', 'Пользователь удален');
    }
}
