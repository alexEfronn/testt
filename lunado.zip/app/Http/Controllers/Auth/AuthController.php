<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\User;
use App\ReferralProfit;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Auth;
use DB;
use GuzzleHttp\Client;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required',
            'password' => 'required'
        ]);

        if($validator->fails()) {
            return [
                'error' => true,
                'message' => $validator->errors()->first()
            ];
        }

        $candidate = User::where('username', $request->username)
            ->where('password', hash('sha256', $request->password))
            ->first();

        if(!$candidate) {
            return [
                'error' => true,
                'message' => 'Пользователь не найден'
            ];
        }

        $candidate->update([
            'used_ip' => $this->getIp()
        ]);

        Auth::login($candidate);
        return 'ok';
    }

    public function registration(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|min:5|max:12',
            'password' => 'required|min:6|max:12',
            'repassword' => 'required|min:6|max:12',
            'token' => 'required'
        ]);

        if($validator->fails()) {
            return [
                'error' => true,
                'message' => $validator->errors()->first()
            ];
        }

        if(!$this->checkRecaptcha($request->token, $this->getIp())) {
            return [
                'error' => true,
                'message' => 'Пройдите капчу'
            ];
        }

        // if(!filter_var($this->getIp(), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {    
        //     return [
        //         'error' => true,
        //         'message' => 'Регистрация с данного IP запрещена'
        //     ];
        // }

        $username = strip_tags($request->username);

        if (!ctype_alnum($username)) {
            return [
                'error' => true,
                'message' => 'Никнейм может содержать только англ. буквы и цифры'
            ];
        }

        if($request->password !== $request->repassword) {
            return [
                'error' => true,
                'message' => 'Пароли не совпадают'
            ];
        }

        try {
            DB::beginTransaction();

            $affectedRow = User::where('username', $username)->first();

            if($affectedRow) {
                DB::rollback();
                return [
                    'error' => true,
                    'message' => 'Логин занят'
                ];
            }

            session_start();
            $ref = null;

            if (isset($_SESSION['ref'])) {
                $ref = $_SESSION['ref'];

                if (!User::query()->find($ref)) {
                    $ref = null;
                }
            }

            $user = User::create([
                'username' => $username,
                'password' => hash('sha256', $request->password),
                'is_vk' => 0,
                'referral_use' => $ref,
                'created_ip' => $this->getIp(),
                'used_ip' => $this->getIp(),
            ]);

            // if(
            //     $ref >= 1 &&
            //     User::where('used_ip', $this->getIp())
            //         ->orWhere('created_ip', $this->getIp())
            //         ->count() <= 1
            // ) {
            //     ReferralProfit::create([
            //         'user_id' => $user->id,
            //         'ref_id' => $ref,
            //         'amount' => $this->config->ref_price
            //     ]);
            //     User::where('id', $ref)->increment('balance', $this->config->ref_price);
            // }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return [
                'error' => true,
                'message' => 'Попробуйте позже'
            ];
        }

        Auth::login($user);

        return 'ok';
    }

    public function checkRecaptcha($token, $ip)
    {
        $response = (new Client)->post('https://www.google.com/recaptcha/api/siteverify', [
            'form_params' => [
                'secret'   => config('recaptcha.secret'),
                'response' => $token,
                'remoteip' => $ip,
            ],
        ]);
        $response = json_decode((string)$response->getBody(), true);
        return $response['success'];
    }
}
