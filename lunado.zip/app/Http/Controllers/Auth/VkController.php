<?php

namespace App\Http\Controllers\Auth;

use Socialite;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Auth;

class VkController extends Controller {

    public function __construct() {
        parent::__construct();
    }

    public function login($provider)
    {
        return Socialite::driver($provider)->redirect();
    }

    public function callback($provider)
    {
		try {
			$user = json_decode(json_encode(Socialite::driver($provider)->stateless()->user()));
		} catch (\Exception $e) {
			return redirect('/')->withError('Попробуйте еще раз');
		}
        //dd($user);
        if(isset($user->returnUrl)) return redirect('/');
        $user = $user->user;
        return $this->createOrUpdateUser($user, $provider);
    }

    public function createOrUpdateUser($user, $provider) {
        if ($provider == 'vkontakte') {
            if($this->user && !$this->user->is_vk) {
                $candidate = User::where('vk_id', $user->id)->count();
                if($candidate > 0) return redirect()->back()->withError('Этот ВК уже привязан');
                
                $this->user->update([
                    'is_vk' => 1,
                    'vk_id' => $user->id
                ]);
                return redirect('/account/bonus');
            }

            if(!$this->user) {
                $candidate = User::where('vk_id', $user->id)->first();
                if(!$candidate) return redirect('/')->withError('Аккаунт не привязан');
    
                Auth::login($candidate, true);
                return redirect('/');
            }

            if($this->user && $this->user->is_vk) {
                $this->user->photo_200 = $user->photo_200;
                $this->user->save();
                return redirect('/settings');
            }
        }
        return $user;
    }
}
