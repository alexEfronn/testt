<?php

namespace App\Http\Controllers\Api;

use App\User;
use App\Withdraw;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;

class WithdrawsController extends Controller
{
    public function get()
    {
        $data = Withdraw::query()
            ->where('status', 3)
            ->where('system_title', 'getpay')
            ->get();
    
        return $data;
    }

    public function setStatus(Request $request)
    {
        $items = $request->data;

        try {
            DB::beginTransaction();

            foreach($items as $item)
            {
                $withdraw = Withdraw::find($item['id']);
                $user = User::find($withdraw->user_id);
    
                if($withdraw->status !== 3) continue;
    
                if($item['status'] == 'success') {
                    $withdraw->update([
                        'status' => 1
                    ]);
                }
    
                if($item['status'] == 'error') {
                    $user->increment('balance', $withdraw->sum);
                    $withdraw->update([
                        'status' => 2,
                        'reason' => 'Выплата отклонена платежной системой'
                    ]);
                }
            }
    
            DB::commit();
        } catch(\Exception $e) {
            DB::rollback();
            return $e->getMessage();
        }

        return [
            'status' => 200
        ];
    }
}