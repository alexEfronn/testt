<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'users';

    protected $fillable = [
        'username', 
        'password', 
        'api_token', 
        'balance', 
        'wager',
        'wager_status',
        'is_vk', 
        'vk_id', 
        'vk_username', 
        'dice', 
        'mines',
        'bubbles',
        'slots',
        'hid', 
        'mines_game', 
        'mines_is_active', 
        'referral_use', 
        'referral_send',
        'referral_use_promo', 
        'referral_percent',
        'is_bot', 
        'created_ip', 
        'used_ip', 
        'is_admin', 
        'is_promocoder', 
        'is_moderator',
        'is_youtuber', 
        'is_worker',
        'privacy_hide',
        'privacy_hide_transfer',
        'chat_ban',
        'chat_ban_reason',
        'ban', 
        'bonus_use', 
        'vk_bonus_use', 
        'tg_bonus_use',
        'game_token',
        'game_token_date'
    ];

    protected $hidden = [
        'remember_token',
    ];
}
