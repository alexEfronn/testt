<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::group(['middleware' => 'secretKey'], function () {
    Route::post('/getTimer', function() {
        return \App\Setting::query()->find(1)->bot_timer;
    });
    Route::post('/fake', 'FakeController@fake');
    Route::post('/promo', 'ChatController@generatePromocode');
    
    // withdraws
    Route::group(['prefix' => 'withdraws', 'namespace' => 'Api'], function () {
        Route::post('/get', 'WithdrawsController@get');
        Route::post('/setStatus', 'WithdrawsController@setStatus');
    });

    // jackpot

    Route::group(['prefix' => 'jackpot'], function () {
        Route::post('/init', 'JackpotController@init');
        Route::post('/roll', 'JackpotController@getWinner');
    });
});