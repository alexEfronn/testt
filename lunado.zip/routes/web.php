<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['prefix' => 'message', 'middleware' => 'auth'], function () {
    Route::post('/init', 'ChatController@init');
    Route::post('/send', 'ChatController@send');
    Route::post('/ban', 'ChatController@ban');
    Route::post('/delete', 'ChatController@delete');
    Route::post('/banlist', 'ChatController@banlist');
    Route::post('/unmute', 'ChatController@unmute');
});

Route::group(['prefix' => 'profile', 'middleware' => 'auth'], function () {
    Route::post('/', 'ProfileController@init');
    Route::post('/send', 'ProfileController@send');
    
    Route::post('/getSettings', 'ProfileController@getSettings');
    Route::post('/save', 'ProfileController@save');
});

Route::any('/config/init', 'IndexController@initConfig');
Route::post('/user/balance', 'IndexController@getBalance');

Route::group(['prefix' => 'events'], function () {
    Route::post('/handle', 'EventsController@handle');
});

Route::group(['prefix' => 'slots'], function () {
    Route::any('/getGames', 'SlotsController@getGames');
    Route::any('/getUrl', 'SlotsController@getGameURI');
    Route::any('/slcallback.php', 'SlotsController@callback');
});

Route::any('/payment/handle', 'PaymentController@handle');
Route::any('/payment/freekassa', 'PaymentController@handleFK');
Route::any('/payment/lpay', 'PaymentController@handleLP');
Route::any('/fkwallet/handle', 'WithdrawController@fkwalletHandle');

Route::post('/getGroupVK', 'IndexController@getGroupVK');
Route::post('/getInfo', 'IndexController@getInfo');

Route::group(['prefix' => '/auth'], function () {
    Route::get('/{provider}', ['as' => 'login', 'uses' => 'Auth\VkController@login']);
    Route::get('/{provider}/callback', 'Auth\VkController@callback');
});

Route::group(['prefix' => '/user'], function () {
    Route::post('/login', 'Auth\AuthController@login');
    Route::post('/registration', 'Auth\AuthController@registration');

    Route::post('/init', 'UserController@init');
    Route::get('/logout', 'UserController@logout');
});

Route::group(['prefix' => 'referrals', 'middleware' => 'auth'], function () {
    Route::post('/get', 'ReferralController@init');
});

Route::group(['prefix' => 'dice', 'middleware' => 'auth'], function () {
    Route::post('/bet', 'DiceController@bet');
});

Route::group(['prefix' => 'bubbles', 'middleware' => 'auth'], function () {
    Route::post('/play', 'BubblesController@play');
});

Route::group(['prefix' => 'mines', 'middleware' => 'auth'], function () {
    Route::post('/init', 'MinesController@init');
    Route::post('/start', 'MinesController@createGame');
    Route::post('/open', 'MinesController@openPath');
    Route::post('/take', 'MinesController@take');
});

Route::group(['prefix' => 'promo', 'middleware' => 'auth'], function () {
    Route::post('/vk', 'PromoController@vk_bonus');
    Route::post('/tg', 'PromoController@tg_bonus');
    Route::post('/getPromo', 'PromoController@getPromo');
    Route::post('/setPromo', 'PromoController@setPromo');
    Route::post('/get', 'PromoController@init');
});

Route::group(['prefix' => 'withdraw', 'middleware' => 'auth'], function () {
    Route::post('/create', 'WithdrawController@create');
    Route::post('/get', 'WithdrawController@getWithdraws');
    Route::post('/decline', 'WithdrawController@decline');
});

Route::group(['prefix' => 'payment', 'middleware' => 'auth'], function () {
    Route::post('/create', 'PaymentController@create');
    Route::post('/get', 'PaymentController@get');
    Route::post('/worker', 'PaymentController@workerPayment');
});

Route::group(['prefix' => 'jackpot'], function () {
    Route::post('/initGame', 'JackpotController@parseJackpot');
    Route::post('/createBet', 'JackpotController@createBet');
    Route::post('/setWinner', 'JackpotController@setWinner');
    Route::post('/history', 'JackpotController@history');
});

Route::group(['prefix' => 'admin', 'namespace' => 'Admin', 'middleware' => 'auth'], function () {
    Route::group(['prefix' => 'promocodes', 'middleware' => 'access:promocoder'], function () {
        Route::get('/', 'PromocodeController@index')->name('admin.promocodes');
        Route::get('/create', 'PromocodeController@create')->name('admin.promocodes.create');
        Route::post('/create', 'PromocodeController@createPost');
        Route::get('/delete/{id}', 'PromocodeController@delete')->name('admin.promocodes.delete');
    });
    Route::group(['middleware' => 'access:admin'], function () {
        Route::post('/load', 'AdminController@load');
        Route::get('/', 'IndexController@index')->name('admin.index');
        Route::get('/users', 'UsersController@index')->name('admin.users');
        Route::get('/bots', 'BotsController@index')->name('admin.bots');
        Route::get('/support', 'SupportController@index')->name('admin.support');
        Route::get('/admins', 'AdminController@index')->name('admin.admins');
        Route::post('/versionUpdate', 'AdminController@versionUpdate');
        Route::post('/getUserByMonth', 'IndexController@getUserByMonth');
        Route::post('/getDepsByMonth', 'IndexController@getDepsByMonth');

        Route::group(['prefix' => 'slots'], function () {
            Route::get('/', 'SlotsController@index')->name('admin.slots');
            Route::get('/update', 'SlotsController@update');
            Route::get('/edit/{id}', 'SlotsController@edit')->name('admin.slots.edit');
            Route::post('/edit/{id}', 'SlotsController@save');
        });

        Route::group(['prefix' => 'users'], function () {
            Route::get('/edit/{id}', 'UsersController@edit')->name('admin.users.edit');
            Route::post('/edit/{id}', 'UsersController@editPost');
            Route::get('/delete/{id}', 'UsersController@delete')->name('admin.users.delete');
        });

        Route::group(['prefix' => 'bots'], function () {
            Route::get('/create', 'BotsController@create')->name('admin.bots.create');
            Route::post('/create', 'BotsController@createPost');
            Route::get('/edit/{id}', 'BotsController@edit')->name('admin.bots.edit');
            Route::post('/edit/{id}', 'BotsController@editPost');
            Route::get('/delete/{id}', 'BotsController@delete')->name('admin.bots.delete');
        });

        Route::group(['prefix' => 'settings'], function () {
            Route::get('/', 'SettingsController@index')->name('admin.settings');
            Route::post('/', 'SettingsController@save');
        });

        Route::group(['prefix' => 'withdraws'], function () {
            Route::get('/', 'WithdrawsController@index')->name('admin.withdraws');
            Route::get('/save/{id}/{status}', 'WithdrawsController@setStatus')->name('admin.withdraws.save');
            Route::post('/decline', 'WithdrawsController@decline');
        });
        Route::group(['prefix' => 'deposits'], function () {
            Route::get('/', 'DepositsController@index')->name('admin.deposits');
        });
        Route::post('/getMerchant', 'IndexController@getMerchant');
    });
});

Route::any('/{any}', 'IndexController@index')->where('any', '.*')->name('index');
