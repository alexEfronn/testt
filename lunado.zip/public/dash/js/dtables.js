"use strict";
var KTDatatablesData = function() {

	var users = function() {
		var table = $('#users');

		table.DataTable({
			responsive: true,
			searchDelay: 500,
			processing: true,
			serverSide: true,
			ajax: {
				url: "/admin/load",
				type: "POST",
				data: {
					type: 'users'
				}
			},
			columns: [
				{ data: "id", searchable: true },
				{ data: "username", searchable: true, orderable: false,
					render: function (data, type, row) {
						return '<a href="/admin/users/edit/' + row.id + '" target="_blank">' + data + '</a>';
					}
				},
				{ data: "balance", searchable: false,
					render: function (data, type, row) {
						return data.toFixed(2) + ' р.';
					}
				},
				{
					data: null, searchable: false, orderable: false,
					render: function (data, type, row) {
						return !row.is_vk 
							? 'Не привязан' 
							: '<a href="https://vk.com/id' + row.vk_id + '" target="_blank">Перейти</a>'
					}
				},
				{ data: "is_admin", searchable: true, orderable: true,
					render: function (data, type, row) {
						var privilege = "";
						if(row.is_admin) privilege += '<span class="kt-badge kt-badge--unified-danger kt-badge--inline kt-badge--pill">Администратор</span>';
						if(row.is_youtuber) privilege += '<span class="kt-badge kt-badge--unified-warning kt-badge--inline kt-badge--pill">Ютубер</span>';
						if(privilege.length == 0) privilege += '<span class="kt-badge kt-badge--unified-primary kt-badge--inline kt-badge--pill">Пользователь</span>';
						return privilege;
					}
				},
				{ data: "created_ip", searchable: true, orderable: false },
				{ data: "used_ip", searchable: true, orderable: false },
				{ 
					data: "ban", searchable: true, orderable: true,
					render: function (data, type, row) {
						return row.ban 
							? '<span class="kt-badge kt-badge--danger kt-badge--inline kt-badge--pill">Да</span>'
							: '<span class="kt-badge kt-badge--success kt-badge--inline kt-badge--pill">Нет</span>'
					}
				},
				{ data: null, searchable: false, orderable: false,
					render: function (data, type, row) {
						return '<a href="/admin/users/edit/'+ row.id +'" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Редактировать"><i class="la la-edit"></i></a>';
					}
				}
			],
			"language": {
				  "processing": "Подождите...",
				  "search": "Поиск:",
				  "lengthMenu": "Показать _MENU_ записей",
				  "info": "Записи с _START_ по _END_ из _TOTAL_ записей",
				  "infoEmpty": "Записи с 0 до 0 из 0 записей",
				  "infoFiltered": "(отфильтровано из _MAX_ записей)",
				  "infoPostFix": "",
				  "loadingRecords": "Загрузка записей...",
				  "zeroRecords": "Записи отсутствуют.",
				  "emptyTable": "В таблице отсутствуют данные",
				  "paginate": {
					"first": "Первая",
					"previous": "Предыдущая",
					"next": "Следующая",
					"last": "Последняя"
				  },
				  "aria": {
					"sortAscending": ": активировать для сортировки столбца по возрастанию",
					"sortDescending": ": активировать для сортировки столбца по убыванию"
				  }
			}
		});
	};

	var bots = function() {
		var table = $('#bots');

		table.DataTable({
			responsive: true,
			searchDelay: 500,
			processing: true,
			serverSide: true,
			ajax: {
				url: "/admin/load",
				type: "POST",
				data: {
					type: 'bots'
				}
			},
			columns: [
				{ data: "id", searchable: true },
				{ data: "username", searchable: true },
				{ data: null, searchable: false, orderable: false,
					render: function (data, type, row) {
						return '\
						<a href="/admin/bots/edit/'+ row.id +'" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Редактировать"><i class="la la-edit"></i></a>\
						<a href="/admin/bots/delete/'+ row.id +'" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Удалить"><i class="la la-trash"></i></a>\
						';
					}
				}
			],
			"language": {
				  "processing": "Подождите...",
				  "search": "Поиск:",
				  "lengthMenu": "Показать _MENU_ записей",
				  "info": "Записи с _START_ по _END_ из _TOTAL_ записей",
				  "infoEmpty": "Записи с 0 до 0 из 0 записей",
				  "infoFiltered": "(отфильтровано из _MAX_ записей)",
				  "infoPostFix": "",
				  "loadingRecords": "Загрузка записей...",
				  "zeroRecords": "Записи отсутствуют.",
				  "emptyTable": "В таблице отсутствуют данные",
				  "paginate": {
					"first": "Первая",
					"previous": "Предыдущая",
					"next": "Следующая",
					"last": "Последняя"
				  },
				  "aria": {
					"sortAscending": ": активировать для сортировки столбца по возрастанию",
					"sortDescending": ": активировать для сортировки столбца по убыванию"
				  }
			}
		});
	};

	var promocodes = function() {
		var table = $('#promocodes');

		table.DataTable({
			responsive: true,
			searchDelay: 500,
			processing: true,
			serverSide: true,
			ajax: {
				url: "/admin/load",
				type: "POST",
				data: {
					type: 'promocodes'
				}
			},
			columns: [
				{ data: "id", searchable: true },
				{ data: "name", searchable: true },
				{ data: "sum", searchable: true },
				{ data: "activation", searchable: true },
				{ data: null, searchable: true, 
					render: function (data, type, row) {
						return Number(row.activation) - Number(row.activated);
					}
				},
				{ data: "type", searchable: true, 
					render: function (data, type, row) {
						return data == 'balance' ? 'Баланс' : 'Депозит';
					}
				},
				{ data: null, searchable: false, orderable: false,
					render: function (data, type, row) {
						return '<a href="/admin/promocodes/delete/'+ row.id +'" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Удалить"><i class="la la-trash"></i></a>';
					}
				}
			],
			"language": {
				  "processing": "Подождите...",
				  "search": "Поиск:",
				  "lengthMenu": "Показать _MENU_ записей",
				  "info": "Записи с _START_ по _END_ из _TOTAL_ записей",
				  "infoEmpty": "Записи с 0 до 0 из 0 записей",
				  "infoFiltered": "(отфильтровано из _MAX_ записей)",
				  "infoPostFix": "",
				  "loadingRecords": "Загрузка записей...",
				  "zeroRecords": "Записи отсутствуют.",
				  "emptyTable": "В таблице отсутствуют данные",
				  "paginate": {
					"first": "Первая",
					"previous": "Предыдущая",
					"next": "Следующая",
					"last": "Последняя"
				  },
				  "aria": {
					"sortAscending": ": активировать для сортировки столбца по возрастанию",
					"sortDescending": ": активировать для сортировки столбца по убыванию"
				  }
			}
		});
	};

	var initTable1 = function() {
		var table = $('#dtable');

		// begin first table
		table.DataTable({
			responsive: true,
			searchDelay: 500,
			"language": {
				  "processing": "Подождите...",
				  "search": "Поиск:",
				  "lengthMenu": "Показать _MENU_ записей",
				  "info": "Записи с _START_ по _END_ из _TOTAL_ записей",
				  "infoEmpty": "Записи с 0 до 0 из 0 записей",
				  "infoFiltered": "(отфильтровано из _MAX_ записей)",
				  "infoPostFix": "",
				  "loadingRecords": "Загрузка записей...",
				  "zeroRecords": "Записи отсутствуют.",
				  "emptyTable": "В таблице отсутствуют данные",
				  "paginate": {
					"first": "Первая",
					"previous": "Предыдущая",
					"next": "Следующая",
					"last": "Последняя"
				  },
				  "aria": {
					"sortAscending": ": активировать для сортировки столбца по возрастанию",
					"sortDescending": ": активировать для сортировки столбца по убыванию"
				  }
			}
		});
	};

	var initTable2 = function() {
		var table = $('#dtable2');

		// begin first table
		table.DataTable({
			responsive: true,
			searchDelay: 500,
			"language": {
				  "processing": "Подождите...",
				  "search": "Поиск:",
				  "lengthMenu": "Показать _MENU_ записей",
				  "info": "Записи с _START_ по _END_ из _TOTAL_ записей",
				  "infoEmpty": "Записи с 0 до 0 из 0 записей",
				  "infoFiltered": "(отфильтровано из _MAX_ записей)",
				  "infoPostFix": "",
				  "loadingRecords": "Загрузка записей...",
				  "zeroRecords": "Записи отсутствуют.",
				  "emptyTable": "В таблице отсутствуют данные",
				  "paginate": {
					"first": "Первая",
					"previous": "Предыдущая",
					"next": "Следующая",
					"last": "Последняя"
				  },
				  "aria": {
					"sortAscending": ": активировать для сортировки столбца по возрастанию",
					"sortDescending": ": активировать для сортировки столбца по убыванию"
				  }
			}
		});
	};

	var initTable3 = function() {
		var table = $('#dtable3');

		// begin first table
		table.DataTable({
			responsive: true,
			searchDelay: 500,
			"language": {
				  "processing": "Подождите...",
				  "search": "Поиск:",
				  "lengthMenu": "Показать _MENU_ записей",
				  "info": "Записи с _START_ по _END_ из _TOTAL_ записей",
				  "infoEmpty": "Записи с 0 до 0 из 0 записей",
				  "infoFiltered": "(отфильтровано из _MAX_ записей)",
				  "infoPostFix": "",
				  "loadingRecords": "Загрузка записей...",
				  "zeroRecords": "Записи отсутствуют.",
				  "emptyTable": "В таблице отсутствуют данные",
				  "paginate": {
					"first": "Первая",
					"previous": "Предыдущая",
					"next": "Следующая",
					"last": "Последняя"
				  },
				  "aria": {
					"sortAscending": ": активировать для сортировки столбца по возрастанию",
					"sortDescending": ": активировать для сортировки столбца по убыванию"
				  }
			}
		});
	};

	return {
		init: function() {
			users();
			bots();
			promocodes();
			initTable1();
			initTable2();
			initTable3();
		},

	};

}();

jQuery(document).ready(function() {
	KTDatatablesData.init();
});