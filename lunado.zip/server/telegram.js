const TelegramBot = require('node-telegram-bot-api');
const mysql = require('mysql');

const bot = new TelegramBot("5975136395:AAFLUQK52HKyPgdoJnaDmMCHivF9G1rUtfM", {
    polling: {
        interval: 300,
        autoStart: true,
        params: {
            timeout: 10
        }
    }
})
const client = mysql.createPool({
    connectionLimit: 50,
    host: "localhost",
    user: "root",
    database: "1",
    password: "1!!"
});

bot.on('message', async msg => {

    let chat_id = msg.chat.id,
        text = msg.text ? msg.text : '',
        settings = await db('SELECT * FROM settings ORDER BY id DESC');

    if(text.toLowerCase() === '/start') {
        return bot.sendMessage(chat_id, `Для привязки Telegram аккаунта, требуется следующее:\n1.Подписаться на наш <a href="https://t.me/12121212121212121">канал</a>\n2. Ввести команду, показанную на <a href="https://cufliks.ru/">сайте</a>`, {
            parse_mode: "HTML",
            disable_web_page_preview: true
        });
    }

    else if(text.toLowerCase().startsWith('/connect')) {
        let id = text.split("/connect ")[1] ? text.split("/connect ")[1] : 'undefined';
        id = id.replace(/[^0-9\s]/gi, "");
        let user = await db(`SELECT * FROM users WHERE id = '${id}'`);
        let check = await db(`SELECT * FROM users WHERE tg_id = ${chat_id}`);
        let subs = await bot.getChatMember('@12121212121212121', chat_id).catch((err) => {});

        if (!subs || subs.status == 'left' || subs.status == undefined) {
            return bot.sendMessage(chat_id, `Вы не подписаны на <a href="https://t.me/12121212121212121">канал</a>`, {
                parse_mode: "HTML",
                disable_web_page_preview: true
            });
        }
        if(user.length < 1) return bot.sendMessage(chat_id, 'Мы не нашли этого пользователя', {
            parse_mode: "HTML"
        });
        if(check.length >= 1) return bot.sendMessage(chat_id, 'Этот аккаунт уже привязан');
        if(user[0].tg_bonus_use == 1) return bot.sendMessage(chat_id, 'Пользователь уже получил награду');

        await db(`UPDATE users SET tg_id = ${chat_id} WHERE id = '${id}'`);
        return bot.sendMessage(chat_id, `Ваш аккаунт успешно привязан`);
    }
});

function db(databaseQuery) {
    return new Promise(data => {
        client.query(databaseQuery, function (error, result) {
            if (error) {
                console.log(error);
                throw error;
            }
            try {
                data(result);

            } catch (error) {
                data({});
                throw error;
            }

        });

    });
    client.end()
}
