const app     = require('express')()
const fs      = require('fs')
const options = {
    key: fs.readFileSync('/etc/letsencrypt/live/madmad.ru/c.pem', 'utf8'),
    cert: fs.readFileSync('/etc/letsencrypt/live/madmad.ru/1.pem', 'utf8')
}
const server  = require('https').createServer(options, app)
const io      = require('socket.io')(server)
const port    = 8443;

server.listen(port)

let online = 0,
    ipsConnected = {}; //список подключенных ip

io.on('connection', async (socket) => {
    let address;

    if (socket.handshake.headers['x-forwarded-for'] !== undefined) {
      address = socket.handshake.headers['x-forwarded-for'];
    } else {
      address = socket.handshake.headers["x-real-ip"];
    }

 if (ipsConnected.hasOwnProperty(address)) {
        ipsConnected[address] = 1;
        online++ ;
    } else {
        ipsConnected[address] += 1;
    }

    this.sendAll('online', online)

     socket.on('disconnect', () => {
        if (ipsConnected.hasOwnProperty(address)) {
        ipsConnected[address] -= 1;

        if (ipsConnected[address] <= 1) {
            delete ipsConnected[address];
            online--;
        }
    }
        
        this.sendAll('online', online)
    });
});

exports.sendAll = (type, data) => {
    io.sockets.emit(type, data)
}

console.log(`Сокет запущен на порте ${port}`)