let redis 	    = require('redis');
let redisClient = redis.createClient();

console.log('Редис запущен')

module.exports = redisClient