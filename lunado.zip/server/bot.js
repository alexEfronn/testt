const domain      = 'https://cashapi.ru';
const RedisClient = require('./utils/redis')
const { sendAll } = require('./utils/socket')
const axios       = require('axios')

let timerBot = null,
    interval = null;

RedisClient.subscribe('newGame');
RedisClient.subscribe('setNewBotTimer');

RedisClient.on('message', async (channel, message) => {
    if (channel === 'setNewBotTimer') {
        clearInterval(interval);
        interval = null;
        timerBot = message;

        startBot();
    } else if(channel == 'newGame') {
        sendAll(channel, JSON.parse(message))
    }
});

const startBot = () => {
    interval = setInterval(() => {
        axios.post(`${domain}/api/fake`)
            .then(res => {

            });
    }, timerBot);
};

const startPromoTimer = () => {
	var now = Math.round(new Date().getTime()/1000);
	var end = Math.round(new Date().getTime()/1000) + 3600;
	var seconds = end - now;

	let startTimer = setInterval(() => {
		if(seconds == 0) {
			clearInterval(startTimer);
			sendPromo();
			return;
		}
		seconds--;
		sendAll('chat.timer', {
			hour: (((seconds - seconds % 3600) / 3600) % 60 < 10 ? '0' + ((seconds - seconds % 3600) / 3600) % 60 : ((seconds - seconds % 3600) / 3600) % 60),
			min: (((seconds - seconds % 60) / 60) % 60 < 10 ? '0' + ((seconds - seconds % 60) / 60) % 60 : ((seconds - seconds % 60) / 60) % 60),
			sec: (seconds % 60 < 10 ? '0' + seconds % 60 : seconds % 60)
		})
	}, 1000)
}

const sendPromo = () => {
    axios.post(`${domain}/api/promo`)
    .then(response => {
        startPromoTimer();
    })
    .catch(err => setTimeout(sendPromo, 1000))
}

exports.init = () => {
    console.log('Боты запущены')
    axios.post(`${domain}/api/getTimer`)
        .then(res => {
            timerBot = res.data;

            startBot();
        });
};

startPromoTimer()
