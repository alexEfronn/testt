let timer       = 20;
let start       = false;
let axios       = require('axios');
let { sendAll } = require('./utils/socket')
let redisClient = require('./utils/redis')

redisClient.subscribe("jackpot");

redisClient.on('message', function(channel, message) {
    if(channel == 'jackpot') {
        message = JSON.parse(message);
        sendAll(channel, message);
    
        if(message.type == 'bet' && message.parse.length >= 2 && !start) startTimer()
    }
})

exports.init = () => {
    axios.post(`https://cashapi.ru/api/jackpot/init`)
    .then(response => {
        const { data } = response;

        if(data.success) {
            if(data.startTimer) startTimer(timer);
        }
    })
    .catch(err => setTimeout(this.init, 1000))
}

const startTimer = (time) => {
    start = true;
    var now = Math.round(new Date().getTime()/1000);
	var end = Math.round(new Date().getTime()/1000) + (time ? time : timer);
	var seconds = end - now;

    sendTimer(seconds)

    let interval = setInterval(() => {
        if(seconds == 0) {
            clearInterval(interval);
            getWinner();
            return;
        }
        seconds--;
        sendTimer(seconds)
    }, 1000)
}

const getWinner = () => {
    console.log('Получаем победителя')
    axios.post(`https://cashapi.ru/api/jackpot/roll`)
    .then(response => {
        const { data } = response;

        if(data.error) {
            sendAll('notify', {
                type: 'error',
                message: data.message
            })
            return startTimer(3);
        }

        start = false;

        setTimeout(() => {
            sendAll('jackpot', {
                type: 'result',
                ...data.winner
            })
        }, 10500)
    })
    .catch(err => console.log(err))
}

const sendTimer = (seconds) => {
    sendAll('jackpot', {
        type: 'timer',
        hour: (((seconds - seconds % 3600) / 3600) % 60 < 10 ? '0' + ((seconds - seconds % 3600) / 3600) % 60 : ((seconds - seconds % 3600) / 3600) % 60),
        min: (((seconds - seconds % 60) / 60) % 60 < 10 ? '0' + ((seconds - seconds % 60) / 60) % 60 : ((seconds - seconds % 60) / 60) % 60),
        sec: (seconds % 60 < 10 ? '0' + seconds % 60 : seconds % 60)
    });
}
