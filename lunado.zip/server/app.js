const bot     = require('./bot')
const jackpot = require('./jackpot')
const chat = require('./chat')

bot.init()
jackpot.init()

console.log('Приложение запущено')