let redisClient = require('./utils/redis')
const { sendAll } = require('./utils/socket')

const channels = [
    'new.message',
    'delete.message',
    'clear.message',
    'transfer'
];

channels.forEach(channel => {
    redisClient.subscribe(channel);
});

redisClient.on('message', function(channel, message) {
    if(channels.includes(channel)) {
        message = JSON.parse(message);
        sendAll(channel, message);
    }
})

console.log('Чат работает')